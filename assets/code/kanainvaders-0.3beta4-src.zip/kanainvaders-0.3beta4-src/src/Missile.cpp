/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Missile.cpp
 *
 * @author Rohin Knight
 * @brief A sprite object which is fired from the player's ship
 */
//============================================================================
#include "Missile.h"
//============================================================================
Missile::Missile()
    : Sprite( new Surface( "data/gfx/missile.png", Color::BLACK ), 35, 35, 40, false ),
      m_Destroyed( false )
{
    createFrameSequence( "destroy", 2, 11 );
    createFrameSequence( "normal", 0, 1, true );
    
    addCollisionRectangle( 14, 0, 7, 30 );
}
//============================================================================
Missile::~Missile()
{

}
//============================================================================
void Missile::setDestroyed( bool destroyed )
{ 
    m_Destroyed = destroyed; 
    
    if ( m_Destroyed )
        setFrameSequence( "destroy" );
    else
        setFrameSequence( "normal" );
}
//============================================================================
void Missile::updateRomanji()
{ 
    if ( Singleton<Input>::getPtr()->keyPressed( SDLK_BACKSPACE ) && ! m_Romanji.empty() ) {
            m_Romanji.erase( m_Romanji.size() - 1 );
    }
    else if ( m_Romanji.size() < 3 && Singleton<Input>::getPtr()->newKeyPressed() ) {
        Uint16 key = Singleton<Input>::getPtr()->getLastKey();
        
        if ( key >= 'a' && key <= 'z' )
            m_Romanji += key;
        else if ( key >= 'A' && key <= 'Z' )
            m_Romanji += tolower( key );
    }
}
//============================================================================
void Missile::updateAnimation()
{
    if ( m_Destroyed && isLastFrame() ) {
        setVisible( false );
        setDestroyed( false );
    }
    else {
        updateFrame();
    }
}
//============================================================================
void Missile::updatePosition()
{
    if ( ! m_Destroyed ) {
        if ( getYPos() > (0 - getHeight()) )
            move( 0, -10 );
        else
            reset();
    }
    else
        move( 0, -1 );
}
//============================================================================
void Missile::reset()
{
    m_Destroyed = false;
    setVisible( false );
    setFrameSequence( "normal" );
    clearRomanji();
}
//============================================================================
