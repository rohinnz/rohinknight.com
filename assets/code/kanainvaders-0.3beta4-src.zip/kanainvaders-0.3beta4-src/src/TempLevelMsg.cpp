/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file TempLevelMsg.cpp
 *
 * @author Rohin Knight
 * @brief A tempory message used to display an instant point win/lose message.
 */
//============================================================================
#include "TempLevelMsg.h"
//============================================================================
TempLevelMsg::TempLevelMsg( string text, Color color, TTF_Font * font )
	: Text( text, color, font )
{
    m_Timeout = 50;
}
//============================================================================
TempLevelMsg::~TempLevelMsg()
{

}
//============================================================================
void TempLevelMsg::update()
{
	if ( --m_Timeout == 0 )
		setVisible( false );
	else
		move( 0, -1 );
}
//============================================================================
