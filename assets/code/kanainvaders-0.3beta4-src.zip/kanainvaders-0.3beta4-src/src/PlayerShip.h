/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file PlayerShip.cpp
 *
 * @author Rohin Knight
 * @brief A sprite object representing the player's ship
 */
//============================================================================
#ifndef PlayerShip_H_
#define PlayerShip_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;

#include "common.h"
//============================================================================
class PlayerShip : public Sprite
{
public:
	PlayerShip();
	virtual ~PlayerShip();

    //void update();
    //void resetPosition();
    void reset( int level );
    
    void updatePosition();
    void updateFlashing();
    
    //void setToFlashing() { m_IsFlashing = true; }
    //bool isFlashing() { return m_IsFlashing; }
    
    void destroy();
    bool destroyTimerFinished();
    
    bool isDestroyed() { return m_Destroyed; }
    
    void setFlashing( bool flashing );
    bool isFlashing();
    
private:
    bool m_Destroyed;
    bool m_IsFlashing;
    int m_CurrentLevel;
    
    //static RCPtr<Surface> PlayerShip::getSurface();
    Timer m_DestroyTimer;
    Timer m_FlashingTimer;
};
//============================================================================
#endif /*PlayerShip_H_*/
//============================================================================
