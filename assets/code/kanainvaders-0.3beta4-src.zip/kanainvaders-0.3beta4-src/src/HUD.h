/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file HUD.h
 *
 * @author Rohin Knight
 * @brief Displays players HUD at top of screen during a level. Displays the
 * current level, wave, lives, and score.
 */
//============================================================================
#ifndef HUD_H_
#define HUD_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;
//============================================================================
class HUD
{
public:
	HUD();
	virtual ~HUD();
    
    void update( int level, int wave, int lives, int points );
    void render();
	
private:
    Text * m_Text;
};
//============================================================================
#endif /*HUD_H_*/
//============================================================================

