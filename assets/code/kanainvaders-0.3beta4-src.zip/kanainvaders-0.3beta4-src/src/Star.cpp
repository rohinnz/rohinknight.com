/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Star.cpp
 *
 * @author Rohin Knight
 * @brief A sprite representing a moving star in the background of a level.
 */
//============================================================================
#include "Star.h"
//============================================================================
Star::Star()
    : Sprite( getSurface(), 1, 1, 0, true, true )
{
    setPosition( 1 + (rand() % (Singleton<Display>::getPtr()->getWidth() - 2)), (rand() % Singleton<Display>::getPtr()->getHeight()) - 10 );
    m_Speed = rand() % 3;
    setFrameIndex( m_Speed );
    m_Counter = 0;
}
//============================================================================
Star::~Star()
{
    
}
//============================================================================
void Star::updatePosition()
{
    ///Display* display = Singleton<Display>::getPtr();
    
    if ( getYPos() > Singleton<Display>::getPtr()->getHeight() ) {
        setPosition( 1 + (rand() % (Singleton<Display>::getPtr()->getWidth() - 2)), 0 - (rand() % 10) );
        m_Speed = rand() % 3;
        setFrameIndex( m_Speed );
        m_Counter = 0;
    }
    else {
        int dy = 0; // set to 0 to prevent compiler warnings
        
        switch ( m_Speed ) {
        case 0:
            dy = (m_Counter % 2 == 0 ? 1 : 0 );
            break;
        case 1:
            dy = (m_Counter % 3 == 0 ? 1 : 0 );
            break;
        case 2:
            dy = (m_Counter % 4 == 0 ? 1 : 0 );
            break;
        }
        
        if ( dy > 0 )
            move( 0, dy );
            
        m_Counter++;
    }
}
//============================================================================
Surface * Star::getSurface()
{
    static Surface* surface =
    	Singleton<GarbageCollector>::getPtr()->addSurface(  // Must use Garbage collector
    		new Surface( "data/gfx/star.png", Color::BLACK )
    	);
 

//    static Surface * surface = new Surface( "data/gfx/star.png", Color::BLACK );
    return surface;
}
//============================================================================
