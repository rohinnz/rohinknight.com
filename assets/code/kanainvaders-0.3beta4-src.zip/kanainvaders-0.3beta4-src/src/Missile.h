/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Missile.h
 *
 * @author Rohin Knight
 * @brief A sprite object which is fired from the player's ship
 */
//============================================================================
#ifndef Missile_H_
#define Missile_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;

#include "common.h"
//============================================================================
class Missile : public Sprite
{
public:
	Missile();
	virtual ~Missile();
    
    bool isDestroyed() { return m_Destroyed; }
    void setDestroyed( bool destroyed );
    
    void updateRomanji();
    void clearRomanji() { m_Romanji = ""; }
    string getRomanji() { return m_Romanji; }
    
    bool isActive() { return ! m_Destroyed && isVisible(); }
    
    void updateAnimation();
    void updatePosition();
    void reset();
    
private:
    string m_Romanji;
    bool m_Destroyed;
    bool m_Active;
};
//============================================================================
#endif /*Missile_H_*/
//============================================================================
