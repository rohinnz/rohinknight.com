/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file SelectLevelScene.h
 *
 * @author Rohin Knight
 * @brief Scene to select level between 1 - 30
 */
//============================================================================
#ifndef SelectLevelScene_H_
#define SelectLevelScene_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;
#include "common.h"
#include "Menu.h"
#include "KanaReviewScene.h"
//============================================================================
class SelectLevelScene : public Scene, public Menu
{
public:
	SelectLevelScene();
	virtual ~SelectLevelScene();

    virtual void started(string selectedLevel);
    virtual void update();
    virtual void render();

private:
    const int LEVEL_TOTAL;
    //vector< RCPtr<Text> > m_Levels;
    Text* m_Levels[ 30 ];  // replaced LEVEL_TOTAL with 30 because compiler was complaining
    Text* m_Title;
    Image* m_Padlock;
    int m_SelectedLevel;
    int m_HighestCompletedLevel;

    TTF_Font * fontNormal;
    string m_Cheat;

    void setupText( const int START, const int END, const int X_POS,
                    int yPos, const int Y_INCREMENT );
    void highlightSelection( bool highlight );
    void selectHighlightedLevel();
    int getHighlightedOptionIndex();

};
//============================================================================
#endif /*SelectLevelScene_H_*/
//============================================================================

