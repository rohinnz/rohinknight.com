/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file HUD.cpp
 *
 * @author Rohin Knight
 * @brief Displays players HUD at top of screen during a level. Displays the
 * current level, wave, lives, and score.
 */
//============================================================================
#include "HUD.h"
//============================================================================
HUD::HUD()
{
    m_Text = new Text( "", Color(111, 217, 113), Singleton<FontManager>::getPtr()->getFont( "HUD" ) );
    m_Text->setPosition( 10, 10 );
}
//============================================================================
HUD::~HUD()
{
    
}
//============================================================================
void HUD::update( int level, int wave, int lives, int points )
{
    //TODO: Calculate where each variable should be displayed. Current method is dirty and needs to be changed whenever the screen width is changed.
    
    char str[500];
    sprintf( str, "Level: %d                  Wave: %d                      Lives: %d                      Points: %d", level, wave, lives, points );
    m_Text->setText( str );
}
//============================================================================
void HUD::render()
{
    m_Text->paint( Singleton<Display>::getPtr()->getSurface() );
}
//============================================================================

