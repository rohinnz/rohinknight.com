/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file KanaCharacter.h
 *
 * @author Rohin Knight
 * @brief Represents any Kana character. Used in the kana review scene and
 * level scene.
 */
//============================================================================
#ifndef KanaCharacter_H_
#define KanaCharacter_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;
#include "common.h"
//============================================================================
class KanaCharacter : public Sprite
{
public:
    static const int NUM_ROMANJI;
    static const string ROMANJI[ /*71*/ ];
    static const int MAX_FRAMES;
    static const int LEVEL_LIMIT[];
    
    KanaCharacter( int frameIndex = 0 );
    virtual ~KanaCharacter();

    static vector< KanaCharacter* > getKanaCharacters( int level );

    string getRomanji();
    void playSound();
    
    bool isActive() { return isVisible() && ! m_Destroyed; }
    //void setActive( bool active ) { m_Active = active; }
    
    void setDestroyed( bool destroyed );
    bool isDestroyed() { return m_Destroyed; }

    static void loadAllSounds();
    
    void reset();

private:
    static Surface * m_KanaSurface;
    bool m_Destroyed;
    
    Surface * getKanaSurface();
    
    //static RCPtr<Sound> SOUNDS[];
    
};
//============================================================================

//============================================================================
#endif /*KanaCharacter_H_*/
//============================================================================
