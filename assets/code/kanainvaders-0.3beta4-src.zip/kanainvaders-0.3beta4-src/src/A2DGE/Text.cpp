/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Text.cpp
 *
 * @author Rohin Knight
 * @brief Displays True Type Font text
 */
//============================================================================
#include "Text.h"
//============================================================================
namespace A2DGE {
//============================================================================
Text::Text( string text, Color color, TTF_Font * font ) 
    : m_Text( text ),
      m_Color( color ),
      m_Font( font )
{
    if ( text.empty() )
        text = " ";
        
    m_Surface = new Surface( TTF_RenderText_Solid( font, text.c_str(), color.getSDL_Color() ) );
}
//============================================================================
Text::~Text()
{

}
//============================================================================
void Text::paint( Surface * destination )
{
    if ( m_Visible )
        m_Surface->blitSurface( destination, m_XPos, m_YPos );
}
//============================================================================
void Text::setText( string text )
{
    //delete m_Surface;
    m_Surface->setSDL_Surface( TTF_RenderText_Solid( m_Font, text.c_str(), m_Color.getSDL_Color() ) );
    //m_Surface = new Surface( TTF_RenderText_Solid( font, text.c_str(), m_color.getSDL_Color() ) );
}
//============================================================================
void Text::setText( string text, Color color, TTF_Font * font )
{
    if ( text.empty() )
        text = " ";
    
    m_Text = text;
    m_Color = color;
    m_Font = font;
        
    m_Surface->setSDL_Surface( TTF_RenderText_Solid( m_Font, m_Text.c_str(), m_Color.getSDL_Color() ) );
//    setColor( color );
//    setFont( font );
//    setText( text );
}
//============================================================================
void Text::setColor( Color color, bool update )
{
    m_Color = color;
    if ( update )
        m_Surface->setSDL_Surface( TTF_RenderText_Solid( m_Font, m_Text.c_str(), m_Color.getSDL_Color() ) );
}
//============================================================================
void Text::setFont( TTF_Font * font, bool update )
{
    m_Font = font;
    if ( update )
        m_Surface->setSDL_Surface( TTF_RenderText_Solid( m_Font, m_Text.c_str(), m_Color.getSDL_Color() ) );
}
//============================================================================
} /* namespace A2DGE */
//============================================================================
