/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file EngineComponent.h
 *
 * @author Rohin Knight
 * @brief Inherited by Singleton classes which are started/stoped in the
 * engine and used throughout the game for graphics, input and sound.
 */
//============================================================================
#ifndef EngineComponent_H_
#define EngineComponent_H_
//============================================================================
#include "Globals.h"
#include "Singleton.h"
//#include "Engine.h"
//============================================================================
//class Engine;
//============================================================================
namespace A2DGE {
//============================================================================
class EngineComponent
{
public:
	EngineComponent();
	virtual ~EngineComponent();
	
	virtual void initialize();
	virtual void shutdown();
	
    //bool isInitialized() { return m_Initialized; }
	
private:
    //bool m_Initialized;

};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*EngineComponent_H_*/
//============================================================================
