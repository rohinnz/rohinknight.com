/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Text.h
 *
 * @author Rohin Knight
 * @brief Displays True Type Font text
 */
//============================================================================
#ifndef Text_H_
#define Text_H_
//============================================================================
#include "Globals.h"
#include "Layer.h"
#include "Surface.h"
#include "Color.h"
//============================================================================
namespace A2DGE {
//============================================================================
class Text : public Layer
{
public:
	Text( string text, Color color, TTF_Font * font );
	virtual ~Text();

    string getText() { return m_Text; }
    void setText( string text );
    void setText( string text, Color color, TTF_Font * font );
    void setColor( Color color, bool update = true );
    void setFont( TTF_Font * font, bool update = true );
    virtual void paint( Surface * destination );

private:
	string m_Text;
	Color m_Color;
	TTF_Font * m_Font;
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Text_H_*/
//============================================================================
