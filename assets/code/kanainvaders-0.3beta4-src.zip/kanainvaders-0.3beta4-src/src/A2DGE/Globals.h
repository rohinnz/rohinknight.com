/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Globals.h
 *
 * @author Rohin Knight
 * @brief include headers which are used by classes in the A2DGE namespace.
 */
//============================================================================
#ifndef Globals_H_
#define Globals_H_
//============================================================================
/* STL Includes */
#include <iostream>
using std::cerr;
using std::endl;

#include <vector>
using std::vector;

#include <map>
using std::map;

#include <set>
using std::set;

#include <string>
using std::string;

#include <sstream>
using std::stringstream;

#include <fstream>
using std::ofstream;
using std::ifstream;
using std::ios;

/* SDL Includes */
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>

/* Other Includes */
#include "string_functions.h"

//============================================================================
#endif /*Globals_H_*/
//============================================================================
