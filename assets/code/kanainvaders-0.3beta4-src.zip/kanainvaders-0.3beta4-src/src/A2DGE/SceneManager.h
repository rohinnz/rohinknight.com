/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file SceneManager.h
 *
 * @author Rohin Knight
 * @brief Engine component which holds all the game scenes and calls their
 * update and render functions when requested by the game engine.
 */
//============================================================================
#ifndef SceneManager_H_
#define SceneManager_H_
//============================================================================
#include "Globals.h"
#include "EngineComponent.h"
#include "Scene.h"
#include "Layer.h"
//============================================================================
namespace A2DGE {
//============================================================================
class SceneManager : public EngineComponent
{
public:
	SceneManager();
	virtual ~SceneManager();

	virtual void initialize();
	virtual void shutdown();

	void addScene( string name, Scene * scene );
	Scene * getScene( string name ) { return m_Scenes[ name ]; }
	void setCurrentScene( string name, string arg = "" );
	void updateCurrentScene();
	void renderCurrentScene();
	
	Scene * getCurrentScene();
	
	void addLayer( string name, Layer * layer);
	Layer* getLayer( string name );
	
private:
    map< string, Scene * > m_Scenes;
    map< string, Layer * > m_Layers;
    Scene * m_CurrentScene;
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*SceneManager_H_*/
//============================================================================
