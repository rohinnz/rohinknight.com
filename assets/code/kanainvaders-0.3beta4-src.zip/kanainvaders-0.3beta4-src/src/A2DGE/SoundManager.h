/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file SoundManager.h
 *
 * @author Rohin Knight
 * @brief Engine component for handling music and sound objects.
 */
//============================================================================
#ifndef SoundManager_H_
#define SoundManager_H_
//============================================================================
#include "Globals.h"
#include "EngineComponent.h"
#include "Sound.h"
#include "Music.h"
//============================================================================
namespace A2DGE {
//============================================================================
class SoundManager : public EngineComponent
{
public:
    static const int DEFAULT_RATE;
    static const Uint16 DEFAULT_FORMAT;
    static const int DEFAULT_CHANNELS;
    static const int DEFAULT_BUFFER_SIZE;
    
    SoundManager();
    virtual ~SoundManager();
    virtual void initialize( int rate = DEFAULT_RATE, Uint16 format = DEFAULT_FORMAT, int channels = DEFAULT_CHANNELS, int bufferSize = DEFAULT_BUFFER_SIZE );
    virtual void shutdown();
    void addSound( string name, string filename );
    void addMusic( string name, string filename );
    Sound getSound( string name );
    Music getMusic( string name );
    bool playSound( string name );
    void playMusic( string name );   
    void stopAllSounds();	
    void stopMusic();
    bool soundExists( string name );
    bool musicExists( string name );
	
private:
    map< string, Mix_Chunk * > m_Sounds;
    map< string, Mix_Music * > m_Music;
	
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*SoundManager_H_*/
//============================================================================
