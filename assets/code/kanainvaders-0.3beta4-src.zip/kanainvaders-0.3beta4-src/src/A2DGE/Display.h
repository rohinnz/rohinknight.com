/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Display.h
 *
 * @author Rohin Knight
 * @brief Holds the primary surface for rendering graphics.
 */
//============================================================================
#ifndef DISPLAY_H_
#define DISPLAY_H_
//============================================================================
#include "Globals.h"
#include "EngineComponent.h"
#include "Surface.h"
//============================================================================
namespace A2DGE {
//============================================================================
class Display : public EngineComponent
{
public:
    static const int DEFAULT_WIDTH;
    static const int DEFAULT_HEIGHT;
    static const int DEFAULT_BPP;
    static const Uint32 DEFAULT_FLAGS;
    
    Display();
	virtual ~Display();
	
	virtual void initialize( int width = DEFAULT_WIDTH, int height = DEFAULT_HEIGHT, int bpp = DEFAULT_BPP, Uint32 flags = DEFAULT_FLAGS );
	virtual void shutdown();
	
	void setWindowCaption( string caption );
	void clearSurface( Uint32 color );
	void swapBuffers();
	Surface* getSurface() { return m_Screen; }
	int getWidth() { return m_Width; }
	int getHeight() { return m_Height; }
	
private:
	Surface* m_Screen;
	int m_Width;
	int m_Height;
	
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Display_H_*/
//============================================================================
