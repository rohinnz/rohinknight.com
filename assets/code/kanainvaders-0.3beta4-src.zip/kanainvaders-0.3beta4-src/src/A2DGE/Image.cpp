/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Image.cpp
 *
 * @author Rohin Knight
 * @brief A static image layer which can be rendered to a Surface.
 */
//============================================================================
#include "Image.h"
//============================================================================
namespace A2DGE {
//============================================================================
Image::Image( string filename )
{	
	m_Surface = new Surface( filename );
}
//============================================================================
Image::Image( Surface* surface )
{
    m_Surface = surface;
}
//============================================================================
Image::~Image()
{

}
//============================================================================
void Image::paint( Surface* destination )
{
    if ( m_Visible )
        m_Surface->blitSurface( destination, m_XPos, m_YPos );
}
//============================================================================
} /* namespace A2DGE */
//============================================================================
