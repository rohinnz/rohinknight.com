/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Singleton.h
 *
 * @author Rohin Knight
 * @brief Implementation of the Singleton design pattern.
 */
//============================================================================
#ifndef Singleton_H_
#define Singleton_H_
//============================================================================
namespace A2DGE {
//============================================================================
template< class T >
class Singleton
{
public:
    static T* getPtr()
    {
        static T m_Instance;
        return &m_Instance;
    }

private:
    Singleton();
    ~Singleton();
    Singleton( Singleton const& );
    Singleton& operator=( Singleton const& );
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Singleton_H_*/
//============================================================================
