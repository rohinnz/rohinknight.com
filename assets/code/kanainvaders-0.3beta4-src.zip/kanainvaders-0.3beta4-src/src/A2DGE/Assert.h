/*
    Another 2D Game Engine (A2DGE) - A collection of C++ classes for
                                     developing multiplatform, 2D, SDL games.
    Copyright (C) 2007  Rohin Knight  

    Another 2D Game Engine is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Another 2D Game Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    

    -- File Info --

    Filename:           Assert.h
    Last modified:      3, January 2008
    Author(s):          Rohin Knight    -   rohin.knight@gmail.com
      
    A custom assert which will throw a STL string containing a parsed error 
    message if the condition is false.
*/
//============================================================================

//TODO: Add doxygen comments with code example

//============================================================================
#ifndef Assert_H_
#define Assert_H_
//============================================================================
namespace A2DGE {
//============================================================================
#ifdef DISABLE_A2DGE_ASSERTS
    #define A2DGE_ASSERT(c, s)

#else
    #define A2DGE_ASSERT(c, s) \
        if ( !(c) ) { \
            string error( "Assert Failed\n" ); \
            error += s; \
            throw error; \
        } \

    #define A2DGE_ASSERTS
      
#endif
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Assert_H_*/
//============================================================================
