/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Layer.h
 *
 * @author Rohin Knight
 * @brief Abstract class inherited by graphic classes like Spire, Image and
 * Text
 */
//============================================================================
#ifndef Layer_H_
#define Layer_H_
//============================================================================
#include "Surface.h"
//============================================================================
namespace A2DGE {
//============================================================================
class Layer
{
public:
	Layer( bool isSharedSurface = false );
    Layer( int xPos, int yPos, bool isSharedSurface = false );
	virtual ~Layer();
	
	virtual void paint( Surface * destination ) = 0;
	void setPosition( int x, int y ) { m_XPos = x; m_YPos = y; }
	void move( int dx, int dy ) { m_XPos += dx; m_YPos += dy; }

	void setXPos( int x ) { m_XPos = x; }
	void setYPos( int y ) { m_YPos = y; }    
	int getXPos() { return m_XPos; }
	int getYPos() { return m_YPos; }
	void setVisible( bool visible ) { m_Visible = visible; }
	bool isVisible() { return m_Visible; }
	
    virtual int getWidth() { return m_Surface->getWidth(); }
    virtual int getHeight() { return m_Surface->getHeight(); }
	
protected:
	Surface * m_Surface;
	bool m_Visible;
	int m_XPos;
	int m_YPos;
	bool m_IsSharedSurface;
};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Layer_H_*/
//============================================================================
