/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Layer.cpp
 *
 * @author Rohin Knight
 * @brief Abstract class inherited by graphic classes like Spire, Image and
 * Text
 */
//============================================================================
#include "Layer.h"
//============================================================================
namespace A2DGE {
//============================================================================
Layer::Layer( bool isSharedSurface )
    : m_Visible( true ),
      m_XPos( 0 ),
      m_YPos( 0 ),
      m_IsSharedSurface( isSharedSurface )
{

}
//============================================================================
Layer::Layer( int xPos, int yPos, bool isSharedSurface )
    : m_Visible( true ),
      m_XPos( xPos ),
      m_YPos( yPos ),
      m_IsSharedSurface( isSharedSurface )
{

}
//============================================================================
Layer::~Layer()
{	
	if (! m_IsSharedSurface) {
		delete m_Surface;		
	}
}
//============================================================================
} /* namespace A2DGE */
//============================================================================
