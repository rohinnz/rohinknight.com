/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Image.h
 *
 * @author Rohin Knight
 * @brief A static image layer which can be rendered to a Surface.
 */
//============================================================================
#ifndef Image_H_
#define Image_H_
//============================================================================
#include "Globals.h"
#include "Layer.h"
#include "Surface.h"
//============================================================================
namespace A2DGE {
//============================================================================
/**
 * @brief An image that has a position, size, and can be rendered to a surface.
 * <p>
 * <h2>Overview</h2>
 * Overview...
 * <h2>Example</h2>
 * Image* background = new Image( "background.png" );
 * Image* player = new Image( new Surface( "player.png", Color::PINK );
 * player->setPosition( 50, Singleton<Display>::getPtr()->getHeight() - player->getHeight() );
 * background->paint( Singleton<Display>::getPtr()->getSurface() )
 * player->paint( Singleton<Display>::getPtr()->getSurface() )
 * </p>
 */
class Image : public Layer
{
public:
    /**
     * Creates an image with the given filename
     * @param[in] filename The image filename
     */
	Image( string filename );
    /**
     * Creates an image with the parsed surface
     * @param[in] surface The image filename
     */
	Image( Surface * surface );
    /**
     * Destructor is currently empty.
     */
	virtual ~Image();
    /**
     * Renders the image to a surface (Can render to another image or the screen)
     * @param[in] destination Surface to render the image on.
     */
    virtual void paint( Surface* destination );

private:

};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Image_H_*/
//============================================================================
