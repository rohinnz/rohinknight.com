/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of A2DGE (Another 2D Game Engine) used as the game engine for
    Kana Invaders - http://sourceforge.net/projects/kanainvaders

    A2DGE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    A2DGE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Repository.h
 *
 * @author Rohin Knight
 * @brief Engine component representing saved game data.
 */
//============================================================================
#ifndef Repository_H_
#define Repository_H_
//============================================================================
#include "Globals.h"
#include "EngineComponent.h"
#include "Engine.h"
//============================================================================
namespace A2DGE {
//============================================================================
class Repository : public EngineComponent
{
public:
	Repository();
	virtual ~Repository();

	virtual void initialize();
	virtual void shutdown();

    void setData( string key, string data );
    void setData( string key, int data );
    string getData( string key );
    void getData( string key, string& data );
    void getData( string key, int& data );

    void setDiskFile( string filename ) { m_Filename = filename; }
    bool loadFromDisk( bool throwExceptionOnFail = true );
    void saveToDisk();

private:
    static const string DEFAULT;
    static const unsigned int MAX_STRING_LENGTH;
    string m_Filename;
    map< string, string > m_Data;
    
    void saveInteger( ofstream& out, int value );
    int loadInteger( ifstream& in );
    void saveString( ofstream& out, string text );
    string loadString( ifstream& in );

};
//============================================================================
} /* namespace A2DGE */
//============================================================================
#endif /*Repository_H_*/
//============================================================================

