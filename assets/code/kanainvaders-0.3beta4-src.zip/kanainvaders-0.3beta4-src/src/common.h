/*
    Kana Invaders - An edutainment game for learning the Japanese
                    Hiragana and Katakana.
    Copyright (C) 2007  Rohin Knight  

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    

    -- File Info --

    Last modified:      3, January 2008
    Author(s):          Rohin Knight  -  rohin.knight@gmail.com
    
    ...
*/
//============================================================================
#ifndef common_H_
#define common_H_
//============================================================================



/* Windows */
#ifdef WIN32
    #include <windows.h>
#endif

/* old c libraries */
#include <stdio.h>

/* STL */
#include <exception>
using std::exception;

#include <string>
using std::string;

#include <vector>
using std::vector;

#include <sstream>
using std::stringstream;

#include <fstream>
using std::fstream;

#include <deque>
using std::deque;

//#include <cstdlib> 

/* old c libraries */
#include <stdio.h>
#include <cstdlib> 
//#include <string>
//#include <cctype>


/* SDL */
#include <SDL/SDL.h>
//============================================================================
#endif /*common_H_*/
//============================================================================
