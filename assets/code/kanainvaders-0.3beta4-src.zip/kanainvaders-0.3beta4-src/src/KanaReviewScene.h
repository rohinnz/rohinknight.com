/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file KanaReviewScene.h
 *
 * @author Rohin Knight
 * @brief Scene to review new Kana characters before starting a level.
 */
//============================================================================
#ifndef KanaReviewScene_H_
#define KanaReviewScene_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;
#include "common.h"
#include "Menu.h"
#include "KanaCharacter.h"
#include "LevelScene.h"
//============================================================================
class KanaReviewScene : public Scene, public Menu
{
public:
	KanaReviewScene();
	virtual ~KanaReviewScene();

    virtual void started(string level);
    virtual void update();
    virtual void render();
    
    void setKanaCharacters();
    
private:
    bool m_StartlevelSelected;
    int m_Index;
    int m_Level;
    
    Text * m_Title;
    Text * m_Message_1;
    Text * m_Message_2;
    Text * m_Level30_Message;
    Text * m_StartLevel;
    
    //RCPtr<Sound> m_ExampleSound;
    
    vector< KanaCharacter * > m_KanaCharacters;
    vector< Text * > m_Romanji;
    
    void highlightSelection( bool highlight );
    void selectHighlightedOption();
    int getHighlightedOptionIndex();

};
//============================================================================
#endif /*KanaReviewScene_H_*/
//============================================================================

