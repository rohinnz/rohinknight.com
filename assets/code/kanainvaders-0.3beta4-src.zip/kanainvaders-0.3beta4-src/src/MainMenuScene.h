/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file MainMenuScene.h
 *
 * @author Rohin Knight
 * @brief The main menu scene
 */
//============================================================================
#ifndef MenuScene_H_
#define MenuScene_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;
#include "common.h"
#include "Menu.h"
//============================================================================
class MainMenuScene : public Scene, public Menu
{
public:
	MainMenuScene();
	virtual ~MainMenuScene();

    virtual void started(string arg);
    virtual void update();
    virtual void render();
    
private:
    enum OPTIONS { NEW_GAME, INSTRUCTIONS, CREDITS, EXIT };
    
    Text * m_Title;
    vector< Text * > m_Options;
    int m_Index;
    
    void highlightSelection( bool highlight );
    void selectHighlightedOption();
    int getHighlightedOptionIndex();

};
//============================================================================
#endif /*MenuScene_H_*/
//============================================================================

