/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file DisplayMessage.cpp
 *
 * @author Rohin Knight
 * @brief Displays a centered, two-line message during a level.
 */
//============================================================================
#include "DisplayMessage.h"
//============================================================================
DisplayMessage::DisplayMessage()
    : displayTime( 2500 )
{
    m_Message = new Text( "", Color(111, 217, 113), Singleton<FontManager>::getPtr()->getFont( "NormalText" ) );
    m_SubMessage =  new Text( "", Color(111, 217, 113), Singleton<FontManager>::getPtr()->getFont( "NormalText" ) );
}
//============================================================================
DisplayMessage::~DisplayMessage()
{

}
//============================================================================
void DisplayMessage::setMessage( string message, string subMessage, bool resetTimer )
{
    m_Message->setText( message );
    m_SubMessage->setText( subMessage );
    
    Display* d = Singleton<Display>::getPtr();
    m_Message->setPosition( (d->getWidth() / 2) - (m_Message->getWidth() / 2),
                            (d->getHeight() / 2) - m_Message->getHeight() );
    m_SubMessage->setPosition( (d->getWidth() / 2) - (m_SubMessage->getWidth() / 2),
                               (d->getHeight() / 2) + 10 );
    
    if ( resetTimer )
        displayTime.reset();
}
//============================================================================
void DisplayMessage::render()
{
    m_Message->paint( Singleton<Display>::getPtr()->getSurface() );
    m_SubMessage->paint( Singleton<Display>::getPtr()->getSurface() );
}
//============================================================================
bool DisplayMessage::isDisplayTimeUp()
{
    return displayTime.intervalReached();
}
//============================================================================
