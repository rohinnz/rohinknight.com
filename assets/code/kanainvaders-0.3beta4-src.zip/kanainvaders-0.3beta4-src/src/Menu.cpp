/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file Menu.cpp
 *
 * @author Rohin Knight
 * @brief Inherited by scene classes with common functionality.
 */
//============================================================================
#include "Menu.h"
//============================================================================
Menu::Menu()
{

}
//============================================================================
Menu::~Menu()
{

}
//============================================================================
void Menu::highlightText( Text* text, bool highlight )
{
    static TTF_Font * fontSelected = Singleton<FontManager>::getPtr()->getFont( "NormalSelected" );
    static TTF_Font * fontNormal = Singleton<FontManager>::getPtr()->getFont( "NormalText" );
    
    
    if ( highlight ) {
        
        
        text->setFont( fontSelected );
        text->setColor( Color(224, 237, 52) );
        
        text->setPosition(
            text->getXPos() - 2,
            text->getYPos() - 2
        );
    }
    else {
        text->setFont( fontNormal );
        text->setColor( Color(111, 217, 113) );
        
        text->setPosition(
            text->getXPos() + 2,
            text->getYPos() + 2
        );
    }  

}
//============================================================================    
void Menu::playChangedSound()
{
    Singleton<SoundManager>::getPtr()->playSound( "pop" );    
}
//============================================================================    
