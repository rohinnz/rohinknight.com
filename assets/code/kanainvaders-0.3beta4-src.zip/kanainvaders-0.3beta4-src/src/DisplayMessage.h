/*
    Copyright (C) 2007-2009 Rohin Knight      
    Part of Kana Invaders - http://sourceforge.net/projects/kanainvaders

    Kana Invaders is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Kana Invaders is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** 
 * @file DisplayMessage.h
 *
 * @author Rohin Knight
 * @brief Displays a centered, two-line message during a level.
 */
//============================================================================
#ifndef DisplayMessage_H_
#define DisplayMessage_H_
//============================================================================
#include "A2DGE/A2DGE.h"
using namespace A2DGE;

#include "common.h"
//============================================================================
class DisplayMessage
{
public:
	DisplayMessage();
	virtual ~DisplayMessage();

    void setMessage( string message, string subMessage, bool resetTimer = true );
    void render();
    bool isDisplayTimeUp();
    //void disappear();
	
private:
    Text * m_Message;
    Text * m_SubMessage;
    Timer displayTime;
};
//============================================================================
#endif /*DisplayMessage_H_*/
//============================================================================
