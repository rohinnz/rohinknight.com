#! /usr/bin/env python
'''
Created on 11 Oct 2010

Code was copied from Which Ways Up (pyweek #4) by Hectic Game Development. 
'''
import sys
import os

try:    
    libdirs = ('model', 'view', 'controller')
    for dir in libdirs:
        libdir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'model'))
        sys.path.insert(0, libdir)
        
except:
    # probably running inside py2exe which doesn't set __file__
    pass

from controller import main
main.main()
