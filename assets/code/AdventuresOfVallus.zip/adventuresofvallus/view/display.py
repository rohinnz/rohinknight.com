'''
Created on 12 Dec 2010

@author: Rohin
'''
import pygame
from events import *

DEFAULT_DISPLAY_TITLE = "Adventures of Vallus (v1.0 dev)"
DEFAULT_SCREEN_WIDTH = 800
DEFAIULT_SCREEN_HEIGHT = 600
#DEFAULT_SCREEN_DIM = (DEFAULT_SCREEN_WIDTH, DEFAIULT_SCREEN_HEIGHT)
DEFAULT_FLAGS = pygame.RESIZABLE
DEFAULT_IS_FULLSCREEN = False

class Display(object):
    def __init__(self):
        self.caption = DEFAULT_DISPLAY_TITLE
        self.width = DEFAULT_SCREEN_WIDTH
        self.height = DEFAIULT_SCREEN_HEIGHT
        self.flags = DEFAULT_FLAGS
        self.is_fullscreen = DEFAULT_IS_FULLSCREEN
        self.depth = 32
        
        self.set_mode()
        pygame.display.set_caption(self.caption)
        
    def set_mode(self):
        self.screen = pygame.display.set_mode((self.width, self.height), self.flags, self.depth)
        
    def set_fullscreen(self, set_fullscreen):
        self.is_fullscreen = set_fullscreen
        
    def resize(self, width, height):
        self.width, self.height = width, height
        pygame.transform.scale(self.screen, (width, height))
            
#    def notify(self, event):
#        pass
            
