'''
Created on 13 Dec 2010

@author: Rohin
'''

#===============================================================================
# INCLUDES
#===============================================================================
import pygame
import math
from vector2 import Vector2

from utils import *
from model import *
from controller.gameclock import *
#from level import *
from display import Display
from menu import Menu
from constants import *

#===============================================================================
# CONSTANTS
#===============================================================================
# --- COLORS ---
COLOR_SKY_BLUE = (59, 185, 255)

# --- DATA FILES ---
DATA_DIR = 'data/'
SOUND_DIR = DATA_DIR + 'sound/'
GFX_DIR = DATA_DIR + 'gfx/'
LEVELS_DIR = DATA_DIR + 'levels/'
FONTS_DIR = DATA_DIR + 'fonts/'

GFX_FILES = {
    'player': GFX_DIR + 'player.bmp',
    'baddie': GFX_DIR + 'baddie.bmp',
    'rock': GFX_DIR + 'rock.bmp',
    'parallax': GFX_DIR + 'parallax.png',
    #'parallax': GFX_DIR + 'parallax-tester.png',
    'xxx bottle': GFX_DIR + 'xxx_bottle3.png'
}

FONT_FILES = {
    'cactus': FONTS_DIR + 'cactus_plain.ttf'
}

LEVEL_FILES = {
    'level1': LEVELS_DIR + 'level1.tmx'
}

# --- ANIMATION ---
STANDING_LEFT, STANDING_RIGHT, WALKING_LEFT, WALKING_RIGHT, JUMPING_LEFT, JUMPING_RIGHT = xrange(6)

#===============================================================================
# FUNCTIONS 
#===============================================================================
def print_text(camera, text, size = 32, colour = (255, 255, 255), position = None, font = None):
    
    
    
    if position == None:
        x = camera.width / 2
        y = camera.height / 2
        position = Vector2(x, y) 
    
    font = pygame.font.Font(FONT_FILES['cactus'], size)
#    font = pygame.font.Font(None, 28)  #TODO: Need to setup this font beforehand so it isn't being called every render.
    text_img = font.render(text, 1, colour)
    #Globals.Screen.blit(text_img, position)
    
    
    camera.draw(text_img, position, True)
    
    
def print_debug_info(screen, clock, level):
    color = (255, 255, 255)        
    font = pygame.font.Font(None, 12)  #TODO: Need to setup this font beforehand so it isn't being called every render.
    text = font.render('FPS: %d - UPS: %d ---- CHEATS = GODMODE: %s - FLY: %s - NO CLIPPING: %s'
                           % (clock.get_fps(), clock.get_ups(), level.cheats_godmode, level.cheats_fly, level.cheats_noclipping), 1, color)
        
    textpos = (10, 10) 
    screen.blit(text, textpos)
    
    
#===============================================================================
# CLASSES
#===============================================================================
class HumanView(object):
    def __init__(self, model, display, clock):
        self.model = model
        self.display = display
        self.clock = clock
        self.level_representation = LevelRepresentation(model.level, display)
        self.level = model.level
        
        self.menu = Menu('GAME PAUSED', ('Resume Game', 'Restart from last checkpoint', 'Restart Level', 'Quit'), display)
        
    def handle_command_input(self, command, is_key_down):
        
        
        if self.level.state == PAUSED:
            if not is_key_down:
                if command == MOVE_UP or command == MOVE_DOWN:
                    self.menu.update_index(command)
                elif command == SELECT:
                    selected_item = self.menu.get_highlighted_item()
                    
                    if selected_item == 'Resume Game':
                        self.level.influence_pause()
                    elif selected_item == 'Restart from last checkpoint':
                        pass
                    elif selected_item == 'Restart level':
                        pass
                    elif selected_item == 'Quit':
                        pass
                    
                    
        elif self.level.state == PLAYING:
            if is_key_down:
                if command == MOVE_UP:
                    self.level.influence_jump()
                elif command == MOVE_LEFT:
                    self.level.influence_move_left()
                elif command == MOVE_RIGHT:
                    self.level.influence_move_right()
            else:
                if command == ACTION_A:
                    self.level.influence_throw_rock()
                elif command == PAUSE:
                    self.level.influence_pause()
                
    def handle_alphanumeric_input(self, character, is_key_down):
        if not is_key_down:
            if character == 'g':
                self.level.influence_toggle_cheat_god_mode() 
            elif character == 'f':
                self.level.influence_toggle_cheat_fly()
            elif character == 'c':
                self.level.influence_toggle_cheat_no_clipping()

    def handle_numeric_input(self, number, is_key_down):
        pass

        
    def update(self):
        
        self.level_representation.update()
        #self.menu.update
        
        # Influence model
        
        # ...
        
        
        
        # Play sound effects and music
        
        # ...
        
        pass
        
    def render(self):
        
        # Draw the level
        
        screen = self.display.screen
        
        self.level_representation.draw_everything(screen)
        
        
        # Now draw everything else
        
        # ....
        
        if self.level.state == PAUSED:
            #print_text(camera, 'GAME PAUSED')
            self.menu.draw(screen)
        
        print_debug_info(screen, self.clock, self.level_representation.level)
        

#=================================================================================================================
class LevelRepresentation(object):
    def __init__(self, level, display):
        self.level = level
        self.player_representation = PlayerRepresentation(self.level.player)
        self.baddie_representation = BaddieRepresentation()
        self.projectile_representation = ProjectileRepresentation()
        
        self.map = level.map
        
        self.display = display
        self.camera = Camera(display.screen, display.width, display.height, level.map_width, level.map_height)
        self.camera.follow(level.player)
        
        self.parallax_background = ParallaxBackground(level.player)
        
        



#    def handle_input(self, input):  # Called before model update
#        
#        state = self.level.state
#        
#        if state == PAUSED:
#            if input == UP or input == DOWN:
#                self.menu.update_index(input)
        

    def update(self):  # Called after model update
        state = self.level.state
        
        if state == PLAYING:
            self.camera.update()
            self.player_representation.update_animation_sequence()
            self.parallax_background.update(self.camera)

    def draw_everything(self, screen):
        state = self.level.state
        camera = self.camera

        # ----- UPDATE ANYTHING WHICH REQUIRES RENDER TIME UPDATING
        if state == PLAYING:
            self.player_representation.update_animation()
            
        # ------ RENDER EVERYTHING
        screen.fill(COLOR_SKY_BLUE)
        self.parallax_background.draw(screen, camera)
        self.draw_tiles(screen, camera)
        self.player_representation.draw(camera)
        
        
        for projectile in self.level.enemy_projectiles:
            self.projectile_representation.draw(camera, projectile)
            
        for baddie in self.level.baddies:
            self.baddie_representation.draw(camera, baddie)

        # Print messages
        if state == PLAYING:
            if not self.level.run_msg_delay.is_time_up():
                print_text(camera, 'RUN!')
            
        if state == GAME_OVER:
            print_text(camera, 'YOU ARE DEAD!')
            
        elif state == PLAYER_WINS:
            print_text(camera, 'YOU WIN!')
        elif state == PAUSED:
            pass
            #print_text(camera, 'GAME PAUSED')
            #self.menu.draw(screen)
                #  self.menu.render()
    
    def draw_entities(self):
        pass
    
    def draw_tiles(self, screen, camera):                        #TODO: Put this in the camera class??
        #camx = camera.position.x # + camera.dx * Globals.Clock.interpolate()
        #camy = camera.position.y # + camera.dy * Globals.Clock.interpolate() 
        
        TILE_WIDTH = 32          #TODO: Read in values from tmx file when it is loaded!
        TILE_HEIGHT = 32
        
        FROM_TILE_X = camera.position.x / TILE_WIDTH
        FROM_TILE_Y = camera.position.y / TILE_HEIGHT
        TO_TILE_X =  (camera.position.x + camera.width) / TILE_WIDTH + 1
        TO_TILE_Y = (camera.position.y + camera.height) / TILE_HEIGHT + 1
        TILE_OFFSET_X = camera.position.x % TILE_WIDTH
        TILE_OFFSET_Y = camera.position.y % TILE_HEIGHT
        
        if FROM_TILE_X < 0:                     FROM_TILE_X = 0
        elif TO_TILE_X > self.map.width:    TO_TILE_X = self.map.width
        if FROM_TILE_Y < 0:                     FROM_TILE_Y = 0
        elif TO_TILE_Y > self.map.height:   TO_TILE_Y = self.map.height
        
        for layer in self.map.layers[:]:
            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):

                    img_idx = layer.content2D[xpos][ypos]      
                    
                    if img_idx:
                        x = (xpos - FROM_TILE_X) * TILE_WIDTH - TILE_OFFSET_X
                        y = (ypos - FROM_TILE_Y) * TILE_HEIGHT - TILE_OFFSET_Y
                        offx, offy, screen_img = self.map.indexed_tile_images[img_idx]   #TODO: Find out what offx and offy are for. They can probably be removed from tiledtmxloader.py
                                                
                        #screen.blit(screen_img, (x, y))   #TODO: Add extra calculations to avoid printing parts of tiles outside of screen (Very low priority)                        
                        camera.draw(screen_img, (x, y), True)

#=================================================================================================================                        
class EntityRepresentation(object):
    def __init__(self):
        pass
    
    def draw(self):
        pass
#=================================================================================================================        
class BaddieRepresentation(EntityRepresentation):
    def __init__(self): 
        tmp_image = load_image(GFX_FILES['baddie'])
        self.image = spriteimage(tmp_image)
        
    def draw(self, camera, baddie):   
        camera.draw(self.image, baddie.position)
#=================================================================================================================
        
class ProjectileRepresentation(EntityRepresentation):
    def __init__(self): 
        tmp_image = load_image(GFX_FILES['rock'])
        self.image = spriteimage(tmp_image)
        
    def draw(self, camera, entity):
        #image = pygame.transform.rotate(self.image, self.angle)
        camera.draw(self.image, entity.position)
        
#=================================================================================================================
class PlayerRepresentation(EntityRepresentation):
    def __init__(self, player):
        self.player = player
        
        fps = 10
        self.right_images = spritesheet(GFX_FILES['player'], (46, 40))
        self.left_images = flip_images(self.right_images)
        self.images = None
        
        #self.set_animation(STANDING_LEFT)
    
        # Track the time we started, and the time between updates.
        # Then we can figure out when we have to switch the image.
        self.current_animation = -1
        #self.start = pygame.time.get_ticks()
        self.delay = 1000 / fps
        self.last_update = 0
        self.frame = 0
        
        self.update_animation_sequence()
        
    def update_animation(self):
        # Note that this doesn't work if it's been more that self._delay time between calls to update(); we only update the image once then, but it really should be updated twice.
        current_ticks = pygame.time.get_ticks()
        if current_ticks - self.last_update > self.delay:
            self.frame += 1
            if self.frame >= len(self.images):
                self.frame = 0
            
            self.last_update = current_ticks

    def update_animation_sequence(self):
        p = self.player

        if p.grounded:
            if p.velocity.x > 0:
                self.set_animation(WALKING_RIGHT)
            elif p.velocity.x < 0:
                self.set_animation(WALKING_LEFT)
            else:
                if self.player.facing == RIGHT:
                    self.set_animation(STANDING_RIGHT)
                else:
                    self.set_animation(STANDING_LEFT)
        else:
            if p.velocity.x > 0:
                self.set_animation(JUMPING_RIGHT)
            elif p.velocity.x < 0:
                self.set_animation(JUMPING_LEFT)
            else:                                                         # TODO: Refactor to remove duplicate code.
                if self.player.facing == RIGHT:
                    self.set_animation(STANDING_RIGHT)
                else:
                    self.set_animation(STANDING_LEFT)

    def set_animation(self, animation):    
        if self.current_animation == animation:
            return 
        
        if animation == WALKING_RIGHT:
            self.images = self.right_images[0:2]
        elif animation == WALKING_LEFT:
            self.images = self.left_images[0:2]
        elif animation == STANDING_RIGHT:
            self.images = self.right_images[0:1]
        elif animation == STANDING_LEFT:
            self.images = self.left_images[0:1]
        elif animation == JUMPING_RIGHT:
            self.images = self.right_images[1:2]
        elif animation == JUMPING_LEFT:
            self.images = self.left_images[1:2]
        else:
            raise "ERROR: No such frame %s" % animation
        
        self.current_animation = animation
        self.frame = 0
        self.last_update = pygame.time.get_ticks()
        
        #self.last_update = 0
        
    def draw(self, camera):
        camera.draw(self.images[self.frame], self.player.position)
        
        #x = self.position.x - camera.position.x
        #y = self.position.y - camera.position.y

        #screen.blit(self.images[self.frame], (x, y)) 
        
        
#=================================================================================================================
class ParallaxBackground(object):
    def __init__(self, player):
        self.player = player
        self.image = load_image(GFX_FILES['parallax'])
        #self.rect = pygame.Rect(0, 0, self.image.get_width(), self.image.get_height())
        self.scroll_speed_x = 0.9
        self.scroll_speed_y = 0.9
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.position = Vector2(0, 0)
        self.y_start_position = player.position.y + 300
        
    def update(self, camera):        
        abs_pos_x = camera.position.x * self.scroll_speed_x
        abs_pos_y = (self.y_start_position - camera.position.y) * self.scroll_speed_y 
        
        # -- Make both integers and calculate the starting x position of the first background in the ribbon
        self.position.x = int(abs_pos_x + int((camera.position.x - abs_pos_x) / self.width) * self.width)            #TODO: Document why we need to convert this to an int: (camera.position.x - abs_pos_x) / self.width
        self.position.y = int(abs_pos_y)
        
    def draw(self, screen, camera):
        
        # --- Calcuate y position
        draw_pos_y = self.y_start_position - self.position.y - camera.position.y
        
        # --- Calculate x position and filler info
        gap_to_fill_x = (camera.position.x + camera.width) - (self.position.x + self.width)
        extra_images_x = int(gap_to_fill_x / self.width)
        last_gap_width_x = math.ceil(gap_to_fill_x % self.width)    # Round up to nearest whole number to get the true width of the final gap to close off
        
        if last_gap_width_x != 0:
            extra_images_x += 1
        
        offset_x = camera.position.x - self.position.x
        offset_y = 0
        
        if draw_pos_y < 0:
            offset_y = -draw_pos_y
            draw_pos_y = 0
        
        draw_pos_x = self.position.x - camera.position.x
        #y = self.position.y
        
        # --- Draw it all
        screen.blit(self.image, (0, draw_pos_y), (offset_x, offset_y, self.width - offset_x, self.height - offset_y))
        
        for i in xrange(extra_images_x):
            draw_pos_x = draw_pos_x + self.width
            
            if i + 1 == extra_images_x and last_gap_width_x != 0:                
                screen.blit(self.image, (draw_pos_x, draw_pos_y), (0, offset_y, last_gap_width_x, self.height - offset_y))
                
                pass
            else:
                screen.blit(self.image, (draw_pos_x, draw_pos_y), (0, offset_y, self.width, self.height - offset_y))
                
                
#=================================================================================================================
class Camera(object):
    def __init__(self, screen, width, height, world_width, world_height):
        self.screen = screen
        self.position = Vector2(0, 0)
        self.width = width
        self.height = height
        self.world_width = world_width
        self.world_height = world_height
        self.target = None
        
    def follow(self, target):
        self.target = target
        
    def update(self):        
        self.position = self.target.position - Vector2(self.width / 2, self.height / 2)

        if self.position.x < 0:
            self.position.x = 0
        elif self.position.x + self.width > self.world_width:
            self.position.x = self.world_width - self.width
            
        if self.position.y < 0:
            self.position.y = 0
        elif self.position.y + self.height > self.world_height:
            self.position.y  = self.world_height - self.height
            
    def draw(self, image, img_position, absolute_position = False):
        if absolute_position:
            self.screen.blit(image, img_position)
        else:
            self.screen.blit(image, img_position - self.position)
#=================================================================================================================

    