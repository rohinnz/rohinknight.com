'''
Created on 12 Oct 2010

@author: Rohin
'''
import pygame
from pygame.locals import *

from objects import *
#from globals import *
#from level import Level

from vector2 import Vector2
from events import *

from constants import *


class FontManager:
    def __init__(self):
        pygame.font.init()
        self.default_font = pygame.font.Font(None, 18)
        #self.default_20 = pygame.font.Font(None,20)

    def get_default_font(self):
        return self.default_font

fontManager = FontManager()


#class Text():
#    def __init__(self, text):
#        self.text = text
#        self.surface
#    
#
#class TextBox():
#    def __init__(self):
#        
#        
#    def set_text(self, text, width = 100):
#        
#        
#        min_width = fontManager.get_small_font().size()
#    
#        
#    def render
#    
#        pygame.draw.polygon(self.displaySurface,(16,16,48),
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)])
#        # Frame it all        
#        pygame.draw.polygon(self.displaySurface,self.borderColor,
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)],
#                            1)


class Menu():
    PADDING = 10
    SIDE_PADDING = 40
    OFFSET_FROM_TITLE = 6
    
    def __init__(self, title, items, display):
        self.position = Vector2(0, 0)
        self.width = 0
        self.height = 0
        
        self.title = title
        self.items = items
        self.index = 0
        self.largest_item_index = self._get_largest_item_index()
        self.item_y_offset = 0
        self.resize_and_center_on_screen(display)
        
        #self.padding = 10
        #self.side_padding = 40
        
    # Uses a very basic search algorithm to find the index of the largest item
    def _get_largest_item_index(self):
        i = 0
        
        for j in xrange(1, len(self.items) - 1):
            if len(self.items[j]) > len(self.items[i]):
                i = j
            
        return i
        
    def resize_and_center_on_screen(self, display):
        largest_item_size = fontManager.get_default_font().size( self.items[self.largest_item_index] )
        
        self.item_y_offset = largest_item_size[HEIGHT] + Menu.PADDING * 2
        
        self.width = largest_item_size[WIDTH] + Menu.SIDE_PADDING * 2
        self.height = (self.item_y_offset) *  (len(self.items) + 1) + Menu.PADDING
                
        self.center_on_screen(display)
                                
    def center_on_screen(self, display):
        self.position.x = display.width / 2 - self.width / 2
        self.position.y = display.height / 2 - self.height / 2        
        
    def get_highlighted_item(self):
        return self.items[self.index]
        
    def update_index(self, direction):
        assert(direction == MOVE_UP or direction == MOVE_DOWN)
        
        if direction == MOVE_UP:
            self.index -= 1
            if self.index < 0:
                self.index = len(self.items) - 1
        
        else:
            self.index += 1
            if self.index == len(self.items):
                self.index = 0
        
                
        
        '''
        if K_UP in Globals.KeysUp:
            self.index -= 1
            if self.index < 0:
                self.index = len(self.items) - 1

        elif K_DOWN in Globals.KeysUp:
            self.index += 1
            if self.index == len(self.items):
                self.index = 0
                
        elif K_RETURN in Globals.KeysUp:     #TODO: Move this code to the menu manager. It should be in whichever class makes the menu items
            if self.items[self.index] == 'Resume Game':
                EventManager().post_event(EVENT_TYPE.PAUSE_LEVEL, False)
            elif self.items[self.index] == 'Restart Level':
                EventManager().post_event(EVENT_TYPE.RESTART_LEVEL)
            elif self.items[self.index] == 'Quit':
                EventManager().post_event(EVENT_TYPE.QUIT)
                '''
        
    def draw(self, screen):
        x_pos_right = self.position.x + self.width
        x_pos_center = self.position.x + self.width / 2
        y_pos_bottom = self.position.y + self.height
         
        
        # -- draw the background
        colour = (60, 60, 170)
        rect = (self.position.x, self.position.y, self.width, self.height)
        pygame.draw.rect(screen, colour, rect, 0)
        
        # -- add the frame
        colour = (0, 0, 30)
        pygame.draw.polygon(screen, colour,
                            [(self.position.x, self.position.y),
                             (self.position.x, y_pos_bottom),
                             (x_pos_right, y_pos_bottom),
                             (x_pos_right, self.position.y)], 1)
        
        pygame.draw.line(screen, colour, (self.position.x, self.position.y + self.item_y_offset), (x_pos_right, self.position.y + self.item_y_offset))
        
        # -- highlight hovered item
        colour = (200, 200, 200)
        
        start_y = self.position.y + self.item_y_offset * self.index + self.item_y_offset + Menu.OFFSET_FROM_TITLE
        end_y = start_y + self.item_y_offset
        left = self.position.x + 5
        right = x_pos_right - 5
        pygame.draw.polygon(screen, colour,
                            [(left, start_y),
                             (left, end_y),
                             (right, end_y),
                             (right, start_y)])
        
        # -- print menu text
        y_pos = self.position.y + Menu.PADDING        
        colour = (255, 255, 255)
        font = fontManager.get_default_font()

        text = font.render(self.title, 1, colour)
        textpos = text.get_rect(centerx=x_pos_center, top=y_pos)
        
        screen.blit(text, textpos)
        
        y_pos += Menu.OFFSET_FROM_TITLE
        
        for i in xrange(len(self.items)):
            
                #color = (200, 0, 0)  # if i == self._index else (200, 200, 200)
                y_pos += self.item_y_offset
                text = font.render(self.items[i], 1, colour)
                textpos = text.get_rect(centerx=x_pos_center, top=y_pos)
                screen.blit(text, textpos)
                
                
#                textpos.top = yPos
#                Globals.Screen.blit(text, textpos)
#                yPos += 40
                #color = (200, 0, 0) if i == self._index else (200, 200, 200)
                #text = font.render(self.items[i], 1, color)
        
        
        
#        BORDER = 2
#        border_rect = pygame.Rect(rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
#        
#        colour = (0, 0, 30)
#        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
#        colour = (60, 60, 170)
#        pygame.draw.rect(Globals.Screen, colour, rect, 0)
        
        
#        pygame.draw.polygon(self.displaySurface,(16,16,48),
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)])
#        # Frame it all        
#        pygame.draw.polygon(self.displaySurface,self.borderColor,
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)],
#                            1)
        
    
#class MenuManager():
#    def __init__(self):
#
#
#
#
#class InLevelMenu():
#    def __init__(self):
#        self._items = ['Resume game', 'New Game', 'Save Game', 'Load Game', 'Quit']
#        
#        # create a surface to paste the border onto
#        
#    def update(self):
#        pass
#    
#    def render(self):
#        rect = pygame.Rect(50, 50, 50, 50)
#        
#        BORDER = 2
#        border_rect = (rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
#        
#        colour = (0, 0, 30)
#        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
#        colour = (60, 60, 170)
#        pygame.draw.rect(Globals.Screen, colour, rect, 0)
#        
#        pass
#    

#class Menu(State):
#    def __init__(self):
#        self._index = 0
# 
#    def update(self):
#        #keys = pygame.key.get_pressed()
#    
#        #if K_RETURN in Globals.KeysUp:
#        #    Globals.StateManager.pushState(SelectLevelMenu())
#
#        if K_UP in Globals.KeysUp:
#            self._index -= 1
#            if self._index < 0:
#                self._index = len(self._items) - 1
#
#        elif K_DOWN in Globals.KeysUp:
#            self._index += 1
#            if self._index == len(self._items):
#                self._index = 0
#
#        #~ elif K_RETURN in KEYS_UP:
#            #~ stateManager.pushState(MenuSelectLevelState())
#
#    def render(self):
#        Globals.Screen.fill((159, 182, 205))
#        yPos = 150
#        font = pygame.font.Font(None, 36)
#        for i in xrange(len(self._items)):
#                color = (200, 0, 0) if i == self._index else (200, 200, 200)
#                text = font.render(self._items[i], 1, color)
#                textpos = text.get_rect(centerx=Globals.Screen.get_width()/2)
#                textpos.top = yPos
#                Globals.Screen.blit(text, textpos)
#                yPos += 40
                

    