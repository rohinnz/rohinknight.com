'''
Created on 12 Dec 2010

@author: Rohin
'''



# -- Have two cameras!