'''
Created on 11 Oct 2010

@author: Rohin
'''
'''Game main module.

Contains the entry point used by the run_game.py script.

Feel free to put all your game code here, or in other modules in this "gamelib"
package.
'''

#-------------------------------------------------------------------------------------------------------------------------------------------------
import pygame
from pygame.locals import *
#import os
#import random
#from sys import exit

from level import *
from globals import *
from gameclock import GameClock
from objects import *
from menu import *
#-------------------------------------------------------------------------------------------------------------------------------------------------
def main():
    engine = Engine()

    if engine.initalize():
        engine.run()
    
    engine.cleanup()
#--------------------------------------------------------------------------------------------------------------------------------------------------
class Engine(object):
    def initalize(self):
        self.game_is_running = True
        pygame.init()
        self.screen = pygame.display.set_mode(SCREEN_DIM, 0, 32)
        pygame.display.set_caption(TITLE)
        #self.clock = pygame.time.Clock()
        
        self.clock = GameClock(TICKS_PER_SECOND, MAX_FPS, CLOCK_USE_WAIT, MAX_FRAME_SKIP)
        self.stateManager = StateManager()
 
        #Globals.Enine = self
        Globals.Screen = self.screen
        Globals.Clock = self.clock
        Globals.StateManager = self.stateManager
        Globals.Use_Interpolation = INTERPOLATION_ENABLED
        
        self.level = Level()
        #self.stateManager.pushState(self.level)
        
        
        EventManager().attach_listener(self)
        
        return True
        
    def cleanup(self): #Empty!
        pass
        
    def update_game(self):                       #TODO: Work out if we need to start calculating delta time.
        
        self.level.update()
#        if self.stateManager.empty():
#            self.game_is_running = False
#        else:
#            self.level.update()
#            #self.stateManager.update()
        
        
        #EventManager().process_events()
        
        #TODO: See if there is a better way to store which keys have been pressed.
        for i in Globals.KeysDown:   Globals.KeysDown.remove(i)
        for i in Globals.KeysUp:       Globals.KeysUp.remove(i)

    def render_game(self):                          #TODO: Start calculating interpolation
        self.level.render()
#        if not self.stateManager.empty():
#            self.stateManager.render()
        
        
        self.print_fps()
        pygame.display.update()
        
        

    def handle_events(self):
        for e in pygame.event.get():
            if e.type == QUIT: self.game_is_running = False
            elif e.type == KEYDOWN:
                Globals.KeysDown.append(e.key)
            elif e.type == KEYUP:
                Globals.KeysUp.append(e.key)

    def run(self):
        while self.game_is_running:
            self.clock.tick()
            if self.clock.update_ready():
                self.update_game()
            if self.clock.frame_ready():
                self.render_game()
            
            self.handle_events()
            
    def notify(self, event):
        if event.type == EVENT_TYPE.QUIT:
            self.game_is_running = False
            
    def print_fps(self):
        if Globals.Use_Interpolation:
            using_interpolation = 'yes'
        else:
            using_interpolation = 'no'
            
        if self.level.cheats_godmode:
            godmode = 'yes'
        else:
            godmode = 'no'
            
        if self.level.cheats_fly:
            fly = 'yes'
        else:
            fly = 'no'
            
        if self.level.cheats_noclipping:
            noclipping = 'yes'
        else:
            noclipping = 'no'
            
        if self.level.cheats_rapid_speed:
            rapid_speed = 'yes'
        else:
            rapid_speed = 'no'
        
        color = (255, 255, 255)        
        font = pygame.font.Font(None, 12)  #TODO: Need to setup this font beforehand so it isn't being called every render.
        text = font.render('FPS: %d - UPS: %d - INTERPOLATION: %s --- CHEATS = GODMODE: %s - FLY: %s - NO CLIPPING: %s - RAPID SPEED %s' % (self.clock.get_fps(), self.clock.get_ups(), using_interpolation, godmode, fly, noclipping, rapid_speed), 1, color)
        textpos = (10, 10) 
        self.screen.blit(text, textpos)

