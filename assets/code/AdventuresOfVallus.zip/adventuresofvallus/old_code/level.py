'''
Created on 12 Oct 2010

@author: Rohin
'''
#--------------------------------------------------------------------------------------------------------------------------------------------------
import math
import pygame
from pygame.locals import *
import random


from tiledtmxloader import *
from globals import *
from objects import *


from utils import *
from events import *

from menu import *


#--------------------------------------------------------------------------------------------------------------------------------------------------
def print_text(camera, text, size = 32, colour = (255, 255, 255), position = None, font = None):
    if position == None:
        position = (camera.rect.width / 2 - 35, camera.rect.height / 2 - 10) 
    
    font = pygame.font.Font(FONT_FILES['cactus'], size)
#    font = pygame.font.Font(None, 28)  #TODO: Need to setup this font beforehand so it isn't being called every render.
    text_img = font.render(text, 1, colour)
    Globals.Screen.blit(text_img, position)
#--------------------------------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------------------------------
class Level(State):
    def __init__(self):
        # --- TEMP VARS
        
        self.tmp_stop = False
        
        
        # --- Load map
        self.map = TileMapParser().parse_decode(LEVEL_FILES['level1'])
        self.map.load(ImageLoaderPygame())
        
        self.indexed_tiles = {}
        for tileset in self.map.tile_sets[:]:
            for tile in tileset.tiles[:]:
                id = int(tileset.firstgid) + int(tile.id)
                self.indexed_tiles[id] = tile                
        
        self.map_width = self.map.layers[0].width * self.map.tilewidth
        self.map_height = self.map.layers[0].height * self.map.tileheight
        
        
        # --- Setup player and baddies
        self.player = Player()
        self.enemy_projectiles = []
        self.baddies = []
        
        self.state = PLAYING
        self.paused = False
        
        #TILE_WIDTH = self.map.tilewidth
        #TILE_HEIGHT = self.map.tileheight
        
        self.gamekeys = GameKeys()

        
        # --- Checkpoints
        self.checkpoints = []
        self.last_checkpoint = None
        
        self.load_game_objs()
        
        # --- Setup camera
        self.camera = Camera(self.map_width, self.map_height)                
        self.camera.update(self.player)
  
        # --- Setup first message to be displayed
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
    
        # --- Cheats
        self.cheats_godmode = False
        self.cheats_fly = False
        self.cheats_noclipping = False
        self.cheats_rapid_speed = False

        # --- Pause menu
        self.menu = Menu('GAME PAUSED', ('Resume Game', 'Restart Level', 'Help', 'Quit'))
        
        # --- parallax background
        self.parallax_background = Parallax()
        
        # --- Register to be notified about events
        EventManager().attach_listener(self)
        
    def return_to_last_checkpoint(self):
        self.paused = False
        self.enemy_projectiles = []
        self.state = PLAYING
        
        self.player = Player()
        self.player.rect.left = self.last_checkpoint.rect.left
        self.player.rect.top = self.last_checkpoint.rect.top + self.last_checkpoint.rect.height - self.player.rect.height
        self.camera.update(self.player)
        
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
        
    def restart_level(self):
        self.paused = False
        self.player = Player()
        self.enemy_projectiles = []
        self.baddies = []
        self.state = PLAYING
        
        self.load_game_objs()
        self.camera = Camera(self.map_width, self.map_height)                
        self.camera.update(self.player)
        
                        
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
        
        #EventManager().post_event(EVENT_TYPE.PLAYER_MOVED, self.player.rect)
        
    def load_game_objs(self):
        #=======================================================================
        # Load objects
        #=======================================================================
        for obj_group in self.map.object_groups:
                for obj in obj_group.objects[:]:
                    name = str.lower(str(obj.name))
                    
                    if name == 'playerstart':
                        self.player.rect.left = obj.x
                        self.player.rect.top = obj.y + TILE_HEIGHT - self.player.rect.height
                    elif name == 'baddie':
                        self.baddies.append(Baddie(obj.x, obj.y))
                    elif name == 'checkpoint':
                        self.checkpoints.append(Checkpoint(obj.x, obj.y, obj.width, obj.height))
                    else:
                        raise 'Unknown object name: %s'  % name
        
    def notify(self, event):
        if event.type == EVENT_TYPE.PAUSE_LEVEL:
            self.paused = event.data
        elif event.type == EVENT_TYPE.RESTART_LEVEL:
            self.restart_level()
                    
    def update(self):
#        if K_ESCAPE in Globals.KeysUp:
#            Globals.StateManager.popState()
#            return
        

        self.handle_input()
        
        if self.state == PLAYING:
            
            if self.paused:
                self.menu.update()
            else:
                #self.camera.update(self.player.rect)
                
                
                
                self.update_player()
                
                
#                if self.tmp_stop:
#                    self.player.dx = 0
                
                self.camera.update(self.player)
                self.parallax_background.update(self.camera)
                
                self.update_projectiles()
                self.update_baddies()
                self.update_messages()
            
        elif self.state == GAME_OVER:
            if self.game_over_msg_delay == None:
                self.game_over_msg_delay = Timer(2000)
            elif self.game_over_msg_delay.is_time_up():
                
                if self.last_checkpoint != None:
                    self.return_to_last_checkpoint()
                else:
                    self.restart_level()
                
        elif self.state == PLAYER_WINS:
            if self.game_over_msg_delay == None:
                self.game_over_msg_delay = Timer(4000)
            elif self.game_over_msg_delay.is_time_up():
                self.restart_level()
                
        #self.handle_input()
                
        
                
        EventManager().process_events()
        
        
        
        
        
        
    def render(self):
        # --Do we need to use interpolation
        use_interpolation = False
        if Globals.Use_Interpolation and self.state == PLAYING and not self.paused:
            use_interpolation = True
            self.camera.calculate_interpolation()
        else:
            self.camera.dx_interpolate = 0
            self.camera.dy_interpolate = 0
            
        # -- Render everything
        Globals.Screen.fill(COLOR_SKY_BLUE)
        self.parallax_background.render(self.camera, use_interpolation)
        
        if self.state in (PLAYING, GAME_OVER, PLAYER_WINS):
            self.render_layers(self.camera, use_interpolation)
            self.player.render(self.camera, use_interpolation) 
            
            
            for rock in self.enemy_projectiles:
                rock.render(self.camera, use_interpolation)
            
            for baddie in self.baddies:
                baddie.render(self.camera, use_interpolation)    
            
#            self.update_messages()
#            if self.brief_message != False and self.brief_message.valid:
#                self.brief_message.render(self.camera)
            
            if not self.run_msg_delay.is_time_up():
                print_text(self.camera, 'RUN!')
            
        if self.state == GAME_OVER:
            print_text(self.camera, 'YOU ARE DEAD!')
            
        elif self.state == PLAYER_WINS:
            print_text(self.camera, 'YOU WIN!')
        else:
            if self.paused:
                self.menu.render()
                
                #print_text(self.camera, 'GAME PAUSED')
                
        
    
    def handle_input(self):
        keysdown = pygame.key.get_pressed()
        #eventManager = EventManager()
        
        if K_ESCAPE in Globals.KeysUp:
            #self.menu.active = not self.menu.active
            self.paused = not self.paused
            Timer.pause_all_timers(self.paused)
            
        if not self.paused:
            if keysdown[self.gamekeys.keys[JUMP]]:
                if self.player.grounded or self.cheats_fly:
                    #eventManager.post_event('make player jump')
                    
                    if self.cheats_rapid_speed:
                        self.player.dy = -RAPID_JUMP_DIST
                    else:
                        self.player.dy = -JUMP_DIST
                    
                    self.player.grounded = False
                        
            if keysdown[self.gamekeys.keys[MOVE_LEFT]]:
                #eventManager.post_event('move player left')
                
                
                if self.cheats_rapid_speed:
                    self.player.dx = -RAPID_PLAYER_SPEED
                else:
                    self.player.dx = -PLAYER_SPEED
                #self.tmp_stop = False
            elif keysdown[self.gamekeys.keys[MOVE_RIGHT]]:
                #eventManager.post_event('move player right')

                if self.cheats_rapid_speed:
                    self.player.dx = RAPID_PLAYER_SPEED
                else:
                    self.player.dx = PLAYER_SPEED
                #self.tmp_stop = False
            else:
                #eventManager.post_event('stop player')
                
                self.player.dx = 0
                
            if K_SPACE in Globals.KeysUp:
                self.player_throw_rock()
                
        # END OF if not self.paused:
                
                
        if K_i in Globals.KeysUp:
            Globals.Use_Interpolation = not Globals.Use_Interpolation
            
        if K_g in Globals.KeysUp:
            self.cheats_godmode = not self.cheats_godmode

        if K_f in Globals.KeysUp:
            self.cheats_fly = not self.cheats_fly
            
        if K_c in Globals.KeysUp:
            self.cheats_noclipping = not self.cheats_noclipping

        if K_r in Globals.KeysUp:            
            self.cheats_rapid_speed = not self.cheats_rapid_speed
            
        if K_s in Globals.KeysUp:
            tps = Globals.Clock.ticks_per_second
                        
            if tps >= 100:
                tps = 5
            else:
                tps += 5
                        
            Globals.Clock.ticks_per_second = tps

    def update_messages(self):
        pass
#        if self.next_keychange_timer.is_time_up():
#            self.gamekeys.shufflekeys()
#            message = 'WARNING: Game keys have been changed!'
#            self.brief_message = BriefMessage(message)
#            self.next_keychange_timer.reset(10000)
#        elif self.brief_message != False and self.brief_message.valid:
#            self.brief_message.update()
                

    def render_layers(self, camera, use_interpolation):                        #TODO: Put this in the camera class??
        camx = camera.rect.left # + camera.dx * Globals.Clock.interpolate()
        camy = camera.rect.top # + camera.dy * Globals.Clock.interpolate() 
        

        #use_interpolation = False

        if use_interpolation:
            camx += camera.dx * Globals.Clock.interpolate()
            camy += camera.dy * Globals.Clock.interpolate()
            camx = int(camx)
            camy = int(camy)

        FROM_TILE_X = camx / TILE_WIDTH
        FROM_TILE_Y = camy / TILE_HEIGHT
        TO_TILE_X =  (camx + camera.rect.width) / TILE_WIDTH + 1
        TO_TILE_Y = (camy + camera.rect.height) / TILE_HEIGHT + 1
        TILE_OFFSET_X = camx % TILE_WIDTH
        TILE_OFFSET_Y = camy % TILE_HEIGHT
        
        if FROM_TILE_X < 0:                     FROM_TILE_X = 0
        elif TO_TILE_X > self.map.width:    TO_TILE_X = self.map.width
        if FROM_TILE_Y < 0:                     FROM_TILE_Y = 0
        elif TO_TILE_Y > self.map.height:   TO_TILE_Y = self.map.height
        
        for layer in self.map.layers[:]:
            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):

                    img_idx = layer.content2D[xpos][ypos]      
                    
                    if img_idx:
                        x = (xpos - FROM_TILE_X) * TILE_WIDTH - TILE_OFFSET_X
                        y = (ypos - FROM_TILE_Y) * TILE_HEIGHT - TILE_OFFSET_Y
                        offx, offy, screen_img = self.map.indexed_tile_images[img_idx]   #TODO: Find out what offx and offy are for. They can probably be removed from tiledtmxloader.py
                        Globals.Screen.blit(screen_img, (x, y))   #TODO: Add extra calculations to avoid printing parts of tiles outside of screen (Very low priority)
        
    def update_player(self):
        
        self.player.update()
        
        if not self.cheats_godmode:
            # Check if we have landed on any spikes
            tile_x, tile_y, img_idx = self.get_death_tile(self.player)
            if img_idx:
                self.state = GAME_OVER
                
            # Check if we have collided with any baddies
            for baddie in self.baddies:
                if self.player.rect.colliderect(baddie.rect):
                    self.state = GAME_OVER
        
        if self.player.rect.left > self.map_width - 200:
            pass
            #self.state = PLAYER_WINS
        
        self.apply_gravity(self.player)
        
        if self.cheats_noclipping:
            self.player.rect.left += self.player.dx
            self.player.rect.top += self.player.dy
        else:
            collision = self.do_x_tile_clipping(self.player)
            
            if collision:
                self.player.dx = 0
                
            self.do_y_tile_clipping(self.player)
            
        self.do_screen_boundary_clipping(self.player)
        
        
        
        # Has player reached a checkpoint?
        for checkpoint in self.checkpoints:
            if self.player.rect.colliderect(checkpoint.rect):
                self.last_checkpoint = checkpoint
                
    def update_baddies(self):
        MAX_DISTANCE = 1000
        MIN_DISTANCE = 100
        
        for baddie in self.baddies:
            if True:
            #if baddie.rect.colliderect(self.camera.rect):

                self.apply_gravity(baddie)
                collision = self.do_x_tile_clipping(baddie)
                
#                if collision:
#                    if baddie.dx > 0:
#                        baddie.dx = -4
#                    else:
#                        baddie.dx = 4
                    
                self.do_y_tile_clipping(baddie)
                self.do_screen_boundary_clipping(baddie)
                
                if baddie.baddie_throw_delay.is_time_up() and \
                   ((baddie.rect.left + MIN_DISTANCE < self.player.rect.left and baddie.rect.left + MAX_DISTANCE > self.player.rect.left) or \
                   (self.player.rect.left + MIN_DISTANCE < baddie.rect.left and self.player.rect.left + MAX_DISTANCE > baddie.rect.left)) and \
                   self.player.rect.top > baddie.rect.top:
                    
                    baddie.baddie_throw_delay.reset(1500)
                    self.baddie_throw_rock(baddie)

     
    def player_throw_rock(self):
        pass
#        DX = 14.0
#        DY = 18.0
#        
#        x = self.player.rect.centerx
#        y = self.player.rect.top
#        
#        if self.player.direction == 'right':
#            dx = DX
#        else:
#            dx = -DX
#        
#        self.enemy_projectiles.append(Projectile(x, y, dx, -DY))
                    
    def baddie_throw_rock(self, baddie):
        
        
        '''
        
        Formula for calculating inital velocity required for projectile to reach player. - Provided by Ashvin
        
        v = dg / sqrt( 2((cosO)^2)gy + 2sinOcosOdg )
        
        Let d = distance
        Let g = gravity
        Let y = velocity
        Let theta = 45 degress in radians
        
        '''


        d = math.fabs(self.player.rect.left - baddie.rect.left)
        y = self.player.rect.top - baddie.rect.top
        theta = math.radians(45)
        
        velocity = d * GRAVITY_SPEED / math.sqrt(2 * (math.cos(theta)**2) *    \
                       GRAVITY_SPEED * y + 2 * math.sin(theta) *               \
                       math.cos(theta) * d * GRAVITY_SPEED)
        
        # --- Get x and y velocities using sine and cosine.
        dx = velocity * math.cos(theta)
        dy = velocity * math.sin(theta)
        
        # --- Make dx negative if projectile is travelling left
        if self.player.rect.left - baddie.rect.left < 0:
            dx = -dx
        
        self.enemy_projectiles.append(Projectile('xxx bottle', baddie.rect.left, baddie.rect.bottom - 50, dx, -dy))

    def update_projectiles(self):
        for projectile in self.enemy_projectiles:
            self.apply_gravity(projectile)
            projectile.update()

            if projectile.rect.top > self.map_height:
                self.enemy_projectiles.remove(projectile)
            elif self.do_x_tile_clipping(projectile): 
                #projectile.dx = 0
                self.enemy_projectiles.remove(projectile)
            elif self.do_y_tile_clipping(projectile):
                
                self.enemy_projectiles.remove(projectile)
            else:
                
                #rect = pygame.Rect(projectile.rect.left, projectile.rect.top, projectile.rect.width, projectile.rect.height)
                #rect.left -=
                
                if not self.cheats_godmode and projectile.rect.colliderect(self.player.rect):
                    self.player.is_sick = True
                    
                    #self.state = GAME_OVER

#                for baddie in self.baddies:
#                    if rock.rect.colliderect(baddie.rect):
#                        self.baddies.remove(baddie)
#                        self.enemy_projectiles.remove(rock)

    def apply_gravity(self, entity):
        if self.cheats_rapid_speed:
            entity.dy += RAPID_GRAVITY_SPEED
            if entity.dy > RAPID_MAX_FALL_SPEED:    entity.dy = RAPID_MAX_FALL_SPEED
        else:
            entity.dy += GRAVITY_SPEED        
            if entity.dy > MAX_FALL_SPEED:    entity.dy = MAX_FALL_SPEED
    
    def do_screen_boundary_clipping(self, entity):
        collision = False
        
        if entity.rect.left < 0:                                                                   
            entity.rect.left = 0
            entity.dx = 0
            collision = True
            
        elif entity.rect.left > self.map_width - entity.rect.width:
            entity.rect.left = self.map_width - entity.rect.width
            entity.dx = 0
            collision = True
            
        if entity.rect.top < 0:                                                              
            entity.rect.top = 0
            entity.dy = 0
            collision = True
            
        elif entity.rect.top > self.map_height - entity.rect.height: 
            entity.rect.top = self.map_height - entity.rect.height
            entity.grounded = True
            entity.dy = 0
            collision = True
            
        return collision
                    
    ## Does x clipping for entity and returns true if there was a collision
    def do_x_tile_clipping(self, entity):
        new_x = entity.rect.left + entity.dx
        tile_x, tile_y, img_idx = self.get_collision_solid_tile(new_x, entity.rect.top, entity)
                
        if img_idx == False:
            entity.rect.left = new_x
            return False
        else:
                # line up with the tile boundary
            if entity.dx > 0:
                entity.rect.left = (tile_x * TILE_WIDTH) - entity.rect.width
            else:  # entity.dx < 0
                entity.rect.left = (tile_x * TILE_WIDTH) + TILE_WIDTH
                
            #assert(entity.dx != 0)
            
            return True
                
    ## Does y clipping for entity and returns true if there was a collision
    def do_y_tile_clipping(self, entity):
        #First check if we are on a platform
        new_y = entity.rect.top + entity.dy
        on_platform = False
        
        if entity.dy > 0:
            tile_x, tile_y, img_idx = self.get_collision_platform_tile(entity.rect.left, new_y, entity)
            
            if img_idx != False:
                on_platform = True
                entity.rect.top = (tile_y * TILE_HEIGHT) - entity.rect.height
                entity.grounded = True
                entity.dy = 0

        #IF we aren't on a platform, then check if we are on a solid
        if on_platform:
            return True
        else:
            tile_x, tile_y, img_idx = self.get_collision_solid_tile(entity.rect.left, new_y, entity)
        
            if img_idx == False:
                entity.rect.top = new_y
                entity.grounded = False
                return False
            else:                                                            # line up with the tile boundary
                if entity.dy > 0:
                    entity.grounded = True
                    entity.rect.top = (tile_y * TILE_HEIGHT) - entity.rect.height 
                else:    # entity.dy > 0
                    entity.rect.top = (tile_y * TILE_HEIGHT) + TILE_HEIGHT    
                    
                #assert(entity.dy != 0) - Can be true if just leaving no clipping
                     
                entity.dy = 0
                return True
                
    def get_death_tile(self, entity):
        from_x = entity.rect.left
        from_y = entity.rect.top
        to_x = from_x
        to_y = from_y
        
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'death')
                
    def get_collision_solid_tile(self, new_x, new_y, entity):
        from_x = min(entity.rect.left, new_x)
        from_y = min(entity.rect.top, new_y)
        to_x = max(entity.rect.left, new_x)
        to_y = max(entity.rect.top, new_y)
                
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'solid')

    def get_collision_platform_tile(self, new_x, new_y, entity):  # You may pass through a platform tile and you can stand on top of it
        from_x = min(entity.rect.left, new_x)
        from_y = entity.rect.top + entity.rect.height + TILE_HEIGHT - 1
        to_x = max(entity.rect.left, new_x)
        to_y = new_y
        
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'platform')
        
    def get_collision_tile(self, from_x, from_y, to_x, to_y, entity, tile_type):   # Will the entity collide with a solid tile?
        FROM_TILE_X = int(from_x) / TILE_WIDTH
        FROM_TILE_Y = int(from_y) / TILE_HEIGHT
        TO_TILE_X =  (int(to_x) + entity.rect.width - 1) / TILE_WIDTH + 1
        TO_TILE_Y = (int(to_y) + entity.rect.height - 1) / TILE_HEIGHT + 1
        
        if FROM_TILE_X < 0:                     FROM_TILE_X = 0
        elif TO_TILE_X > self.map.width:    TO_TILE_X = self.map.width
        if FROM_TILE_Y < 0:                     FROM_TILE_Y = 0
        elif TO_TILE_Y > self.map.height:   TO_TILE_Y = self.map.height
            
        # -- All layers are treated as visible
        for layer in self.map.layers[:]:
            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):

                    img_idx = layer.content2D[xpos][ypos]      
                    
                    #if img_idx:
                    if img_idx and img_idx in self.indexed_tiles:       # -- Check for collision
                        tile = self.indexed_tiles[img_idx]
                        
                        if tile_type in tile.properties:
                            return (xpos, ypos, img_idx)

        return (0, 0, False) 
    
    
    # TEMP code below
    
    def tmp_draw_shapes(self, camera):
    
        rect = pygame.Rect(50, 50, 50, 50)
        
        BORDER = 2
        border_rect = (rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
        
        colour = (0, 0, 30)
        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
        colour = (60, 60, 170)
        pygame.draw.rect(Globals.Screen, colour, rect, 0)
        

        
        #pointlist = ((20, 20), (20, 40), (40, 40), (40, 20))
        
        #pygame.draw.polygon(Globals.Screen, colour, pointlist, 0)
              
        #colour = (0, 200, 0)
        #pygame.draw.aaline(Globals.Screen, colour, (20, 20, 4), (300, 300, 4), 1)
        
