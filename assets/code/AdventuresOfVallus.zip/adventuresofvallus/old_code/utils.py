'''
Collection of useful classes and functions, copied from all over the place.


'''


#TODO: Dump all functions here which are used for loading images, etc



import os
import pygame


data_py = os.path.abspath(os.path.dirname(__file__))
data_dir = os.path.normpath(os.path.join(data_py, '..', 'data'))


# Enum code copied from http://code.activestate.com/recipes/577024-yet-another-enum-for-python/
def enum(typename, field_names):
    "Create a new enumeration type"

    if isinstance(field_names, str):
        field_names = field_names.replace(',', ' ').split()
    d = dict((reversed(nv) for nv in enumerate(field_names)), __slots__ = ())
    return type(typename, (object,), d)()
'''
You define an enumeration the same way as collections.namedtuple: with a type name, followed by a sequence of identifiers (it may be a string separated by commas and/or whitespace):

>>> STATE = enum('STATE', 'GET_QUIZ, GET_VERSE, TEACH')

It returns a (single) instance of a newly created type. The enumeration elements are integers, starting at 0, exposed as attributes. There is no way to change that: if you need specific values, look elsewhere. In fact, it is as if the enum were declared as:
'''


# Singleton copied from ...
def singleton(cls):
    instance_container = []
    def getinstance():
        if not len(instance_container):
            instance_container.append(cls())
        return instance_container[0]
    return getinstance


#BEGIN Utils code
def filepath(path):
    if "/" in path:
        path = path.split("/")
    elif "\\" in path:
        path = path.split("\\")
    if type(path) is type([]):
        return os.path.join(*path)
    else:
        return os.path.join(path)

IMAGES = {}
def load_image(filename):
    if filename not in IMAGES:
        
        IMAGES[filename] = pygame.image.load(filename).convert_alpha()
        
        
        #IMAGES[filename] = pygame.image.load(
        #    filepath(filename)).convert_alpha()
    return IMAGES[filename]


def spriteimage(image, colourkey = (0, 0, 0)):
    surface = pygame.Surface((image.get_width(), image.get_height()))
    surface.fill((1, 48, 6))
    surface.set_colorkey(colourkey, pygame.RLEACCEL)
    surface.blit(image, (0, 0))
    return surface

def spritesheet(image, size, colourkey = (0, 0, 0)):
    images = []
    img = load_image(image)
    for y in range(img.get_height()/size[1]):
        for x in range(img.get_width()/size[0]):
            i = pygame.Surface(size)
            i.fill((1, 48, 6))
            i.set_colorkey(colourkey, pygame.RLEACCEL)
            i.blit(img, (-x*size[0], -y*size[1]))
            images.append(i)
    return images


def flip_images(images):
    new = []
    for i in images:
        new.append(pygame.transform.flip(i, 1, 0))
    return new



#def filepath(filename):
#    '''Determine the path to a file in the data directory.
#    '''
#    return os.path.join(data_dir, filename)

def load(filename, mode='rb'):
    '''Open a file in the data directory.

    "mode" is passed as the second arg to open().
    '''
    return open(os.path.join(data_dir, filename), mode)

def find(f, seq):
    """Return first item in sequence where f(item) == True."""
    for item in seq:
        if f(item):
            return True
        
