'''
Created on 12 Oct 2010

@author: Rohin
'''
'''
Created on 12 Oct 2010

@author: Rohin
'''

#TODO: consider putting all entities in a seperate module called entities

#-------------------------------------------------------------------------------------------------------------------------------------------------
import os
import pygame
from pygame.locals import *
#from pygame.surfarray import *
import pygame.surfarray as surfarray
from numpy import *

from gameclock import *
from globals import *
from utils import *
from events import *

class Timer():
    #Timers_Paused = False
    Ticks_On_Pause = 0
    Paused_Ticks = 0
    
    def __init__(self, delay = 2000):
        self.end_ticks = pygame.time.get_ticks() + delay
        
    def reset(self, delay = 2000):
        self.end_ticks = pygame.time.get_ticks() + delay
        
    def is_time_up(self):
        return ( pygame.time.get_ticks() > self.end_ticks + Timer.Paused_Ticks)
    
    @classmethod
    def pause_all_timers(cls, pause_timers):
        if pause_timers:
            #Timers_Paused = True
            cls.Ticks_On_Pause = pygame.time.get_ticks()
        else:
            cls.Paused_Ticks = pygame.time.get_ticks() - cls.Ticks_On_Pause


#-------------------------------------------------------------------------------------------------------------------------------------------------
class State(object):
    def update(self):
        pass

    def render(self):
        pass
#-------------------------------------------------------------------------------------------------------------------------------------------------
class StateManager(object):
    def __init__(self): 
        self._states = []
    
    def pushState(self, state):
        self._states.append(state)

    def popState(self):
        return self._states.pop()

    def setState(self, state):
        self._states[-1] = state

    def update(self):
        self._states[-1].update()

    def render(self):
        self._states[-1].render()
        
    def empty(self):
        return not self._states

#-------------------------------------------------------------------------------------------------------------------------------------------------






class Entity(object):
    def __init__(self):
        self.rect = False
        self.alive = True
        self.visible = True
        
    def update(self):
        pass
        
    def render(self):
        pass
    
    def die(self):
        self.alive = False
#-------------------------------------------------------------------------------------------------------------------------------------------------
class Player(Entity):
    def __init__(self, fps = 5):
        #pygame.sprite.Sprite.__init__(self)
        
        
            #TODO: Find a better way for creating the collision rectangle
        #self.tmp_offset_x = 9
        
        
        self.firing = False
        self.grounded = False
        self.dx = 0
        self.dy = 0
        
        self.direction = 'right'
        
        self.right_images = spritesheet(GFX_FILES['player'], (46, 40))
        self.left_images = flip_images(self.right_images)
        
        self.set_animation('standing right')
        
        #self.image = self.right_images[0]
        #self.all_images = spritesheet("../data/gfx/playership.png", (68, 64))
#        self.images = self.right_images[0:2]
#        
#        self.image = self.images[0]
        
        
            #TODO: Find a better way for creating the collision rectangle
        self.rect = pygame.Rect(20, 20, self.images[0].get_width(), self.images[0].get_height())
            
        #self.rect = pygame.Rect(20, 20, self.images[0].get_width() - (self.tmp_offset_x + 7), self.images[0].get_height())
        #self.rect = pygame.Rect(20, 20, self.image.get_width(), self.image.get_height())
        
    #~ self.dying_images = self._images[2:6]


        # Track the time we started, and the time between updates.
        # Then we can figure out when we have to switch the image.
        self.start = pygame.time.get_ticks()
        self.delay = 1000 / fps
        self.last_update = 0
        self.frame = 0
    
        # Call update to set our first image.
        
        #self.worksurf = pygame.Surface((self.rect.width, self.rect.height))
        self.sick = True
        
        self.update()
        
        




    def set_animation(self, animation):    
        if animation == 'walking right':
            self.images = self.right_images[0:2]
        elif animation == 'walking left':
            self.images = self.left_images[0:2]
        elif animation == 'standing right':
            self.images = self.right_images[0:1]
        elif animation == 'standing left':
            self.images = self.left_images[0:1]

#        elif animation == 'jumping right':
#            self.images = self.right_images[1:2]
#            self.image = self.right_images[0]
#        elif animation == 'jumping left':
#            self.images = self.left_images[1:2]
#            self.image = self.left_images[0]
        else:
            print "ERROR: No such frame %s" % animation
            
        print 'setting animation to %s'  % animation

        self.current_animation = animation
        self.frame = 0
        self.last_update = pygame.time.get_ticks()
        
        #self.last_update = 0

    def update(self):
        #print 'self.dx %d' % self.dx
        #print 'self.grounded: %d' % self.grounded
        
        if self.dx > 0:
            if self.grounded:
                if self.current_animation != 'walking right':
                    self.set_animation('walking right')
            elif self.current_animation != 'standing right':
                self.set_animation('standing right')
                
            self.direction = 'right'
        elif self.dx < 0:
            if self.grounded:
                    if self.current_animation != 'walking left':
                        self.set_animation('walking left')
            elif self.current_animation != 'standing left':
                self.set_animation('standing left')
                
            self.direction = 'left'
        else:
            if self.current_animation == 'walking right':
                self.set_animation('standing right')
            elif self.current_animation == 'walking left':
                self.set_animation('standing left')
            
        #-------------------------------------------------------------------------
        #Update animation
        
        # Note that this doesn't work if it's been more that self._delay
        # time between calls to update(); we only update the image once
        # then, but it really should be updated twice.
        current_ticks = pygame.time.get_ticks()  #pygame.time.get_ticks()
        if current_ticks - self.last_update > self.delay:
            self.frame += 1
            if self.frame >= len(self.images):
                self.frame = 0
            
#                self.image = self.images[self.frame]
            self.last_update = current_ticks                
                #self.display_red = not self.display_red
            
    def render(self, camera, use_interpolation = True):
        x = self.rect.left - camera.rect.left
        y = self.rect.top - camera.rect.top
        
        #use_interpolation = False
        
        if use_interpolation:
            x -= camera.dx_interpolate
            y -= camera.dy_interpolate
            
            x += self.dx * Globals.Clock.interpolate()
            y += self.dy * Globals.Clock.interpolate()

            
            #TODO: Remove interpolation glitch by testing if interpolate vector has a collision. Very low priority!
            # Remove the interpolation collision glitch
#            entity = Entity()
#            entity.rect
            
        Globals.Screen.blit(self.images[self.frame], (x, y)) 
        



class Rock(pygame.sprite.Sprite):
    def __init__(self, x, y, dx, dy):
        pygame.sprite.Sprite.__init__(self)
        tmp_image = load_image(GFX_FILES['rock'])
        self.image = spriteimage(tmp_image)
        self.rect = pygame.Rect(x, y, self.image.get_width(), self.image.get_height())
        self.dx = dx
        self.dy = dy
    
    def render(self, camera, use_interpolation = True):
        x = self.rect.left - (camera.rect.left + camera.dx_interpolate)
        y = self.rect.top - (camera.rect.top + camera.dy_interpolate)
        
        
        if use_interpolation:
            x += self.dx * Globals.Clock.interpolate()
            y += self.dy * Globals.Clock.interpolate()
        
        Globals.Screen.blit(self.image, (x, y))
        
class Baddie(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        tmp_image = load_image(GFX_FILES['baddie'])
        self.image = spriteimage(tmp_image)
        self.rect = pygame.Rect(x, y, self.image.get_width(), self.image.get_height())
        self.dx = 0
        self.dy = 0
        self.grounded = False
        self.baddie_throw_delay = Timer(2000)
        
    def render(self, camera, use_interpolation = True):
        x = self.rect.left - (camera.rect.left + camera.dx_interpolate)
        y = self.rect.top - (camera.rect.top + camera.dy_interpolate)
        
        #use_interpolation = False
        if use_interpolation:
            x += self.dx * Globals.Clock.interpolate()
            y += self.dy * Globals.Clock.interpolate()
        
        Globals.Screen.blit(self.image, (x, y))
        
        
        
        
        

 #TODO: DOCUMENT EVERYTHING!!!
 #TODO: Try and simplify code        
 #TODO: Base position off player, rather than camera.
class Parallax(object):
    def __init__(self):
        self.image = load_image(GFX_FILES['parallax'])
        self.rect = pygame.Rect(0, 0, self.image.get_width(), self.image.get_height())
        #self.dx = 0
        #self.dy = 0
        
    def update(self, camera):        
        new_pos = camera.rect.left * 0.7        
        self.rect.left = new_pos + int((camera.rect.left - new_pos) / self.rect.width) * self.rect.width
        
    def render(self, camera, use_interpolation = True):
        
        x = self.rect.left
        
        if use_interpolation:
            x += camera.dx_interpolate * 0.7

        cam_x = camera.rect.left + camera.dx_interpolate
        
        gap_to_fill = (camera.rect.right + camera.dx_interpolate) - (x + self.rect.width)
        
        num_extra_images = int(gap_to_fill / self.rect.width)
        
        last_gap = math.ceil(gap_to_fill % self.rect.width)    # Round up to nearest whole number to get the true width of the final gap to close off
        
        if last_gap != 0:
            num_extra_images += 1
        
#        if gap_to_fill > 0:
#            num_extra_images = int(gap_to_fill / self.rect.width)
#        
#            last_gap = math.ceil(gap_to_fill % self.rect.width)    # Round up to nearest whole number to get the true width of the final gap to close off
#        
#            if num_extra_images > 0 and last_gap != 0:
#                num_extra_images += 1
#        else:
#            num_extra_images = 0
#            last_gap = 0
        
#        if num_extra_images > 0 and gap_to_fill % self.rect.width != 0:
#            num_extra_images += 1
        
        
        #print 'gap to fill: %d' % gap_to_fill
        
        x_temp = x
        x -= cam_x
        y = self.rect.top    # + camera.dy_interpolate
        

        #Globals.Screen.blit(self.image, (x, y))    #TODO: crop out-of-camera part of image
        
        offset_x = cam_x - x_temp
        
        Globals.Screen.blit(self.image, (0, y), (offset_x, 0, self.rect.width - offset_x, self.rect.height))    #TODO: crop out-of-camera part of image
        
        for i in xrange(num_extra_images):
            x = x + self.rect.width
            
            if i + 1 == num_extra_images and last_gap != 0:
                #right_offset_x = (camera.rect.right + camera.dx_interpolate) - x - 50
                
                #last_gap = camera.rect.right + camera.dx_interpolate - x - 50
                
                Globals.Screen.blit(self.image, (x, y), (0, 0, last_gap, self.rect.height))
            else:
                Globals.Screen.blit(self.image, (x, y))      #TODO: crop out-of-camera part of image
        
#        if cam_x + camera.rect.width > x + self.rect.width:
#            x = x + self.rect.width
#            Globals.Screen.blit(self.image, (x, y))
#        if use_interpolation:
#            x = (camera.rect.left + camera.dx_interpolate) * 0.7
#        else:
#            x = self.rect.left
#
#        cam_x = camera.rect.left + camera.dx_interpolate
#        x -= cam_x
#        y = self.rect.top    # + camera.dy_interpolate
#        
#
#        Globals.Screen.blit(self.image, (x, y))       # This is really bad. We should only blit what is visible to the camera
#        
#        if cam_x + camera.rect.width > x + self.rect.width:
#            x = x + self.rect.width
#            Globals.Screen.blit(self.image, (x, y))
            

        
class Projectile(object):
    def __init__(self, name, x, y, dx, dy):
        self.image = load_image(GFX_FILES[name])
        self.rect = pygame.Rect(x, y, self.image.get_width(), self.image.get_height())
        self.dx = dx
        self.dy = dy
        self.angle = 0
        self.rotate_speed = 10
    
    def update(self):
        self.angle += self.rotate_speed
     
    def render(self, camera, use_interpolation = True):
        
        x = self.rect.centerx - camera.rect.left
        y = self.rect.centery - camera.rect.top    
        #x = self.rect.left - camera.rect.left
        #y = self.rect.top - camera.rect.top
        angle = self.angle
        
        if use_interpolation:
            #x -= camera.dx_interpolate
            #y -= camera.dy_interpolate
            
            x += self.dx * Globals.Clock.interpolate() - camera.dx_interpolate
            y += self.dy * Globals.Clock.interpolate() - camera.dy_interpolate
            angle += self.rotate_speed * Globals.Clock.interpolate()
            

        image = pygame.transform.rotate(self.image, angle)
        Globals.Screen.blit(image, (x, y))

        
class Factory(object):     # Factory design pattern
    def add_baddie(self):
        pass
        
    def add_player(self):
        pass
    
    def add_rock(self):
        pass
    
    
class Checkpoint(object):
    def __init__(self, x, y, w, h):
        self.rect = pygame.Rect(x, y, w, h)
        
        
class Camera(EventListener):
    def __init__(self, world_width, world_height):
        EventManager().attach_listener(self)
        self.dx = 0
        self.dy = 0
        self.dx_interpolate = 0
        self.dy_interpolate = 0
        self.rect = pygame.display.get_surface().get_rect()       #set camera to be same size as screen
        self.world_rect = pygame.Rect(0, 0, world_width, world_height)
        
    def calculate_interpolation(self):
        self.dx_interpolate = self.dx * Globals.Clock.interpolate()
        self.dy_interpolate = self.dy * Globals.Clock.interpolate()
        
    def update(self, player):
        #dx = player.rect.centerx - self.rect.centerx
        #dy = player.rect.centery - self.rect.centery
        
        self.rect.centerx = player.rect.centerx
        self.rect.centery = player.rect.centery
        
        
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > self.world_rect.width:
            self.rect.right = self.world_rect.width
            
        if self.rect.top < 0:
            self.rect.top = 0
        elif self.rect.bottom > self.world_rect.height:
            self.rect.bottom = self.world_rect.height

        
    def notify(self, event):
        pass
        #if event.type == EVENT_TYPE.PLAYER_MOVED:
        #    self.update(event.data)
            
    def render(self):
        pass
    
    
class BriefMessage():
    def __init__(self, message):
        self.timer = Timer()
        self.message = message
        self.font = pygame.font.Font(None, 28)
        self.color = (160, 20, 20)
        self.valid = True
        
    def update(self):
        if self.timer.is_time_up():
            self.valid = False

    def render(self, camera):
        text = self.font.render(self.message, 1, self.color)
        textpos = (camera.rect.width / 2 - 30, camera.rect.height / 2 - 20) 
        Globals.Screen.blit(text, textpos)
        
class GameKeys():
    def __init__(self):
        self.keys = [K_UP, K_LEFT, K_RIGHT, K_DOWN]

    def shufflekeys(self):
        random.shuffle(self.keys)
        
    def swapkeys(self):
        self.keys[MOVE_LEFT] = K_RIGHT
        self.keys[MOVE_RIGHT] = K_LEFT
        
    def restorekeys(self):
        self.keys[MOVE_LEFT] = K_LEFT
        self.keys[MOVE_RIGHT] = K_RIGHT
    