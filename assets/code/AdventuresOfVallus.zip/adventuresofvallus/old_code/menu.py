'''
Created on 12 Oct 2010

@author: Rohin
'''
import pygame
from pygame.locals import *

from objects import *
from globals import *
#from level import Level

from events import *


class FontManager:
    def __init__(self):
        pygame.font.init()
        self.default_font = pygame.font.Font(None, 18)
        #self.default_20 = pygame.font.Font(None,20)

    def get_default_font(self):
        return self.default_font

fontManager = FontManager()


#class Text():
#    def __init__(self, text):
#        self.text = text
#        self.surface
#    
#
#class TextBox():
#    def __init__(self):
#        
#        
#    def set_text(self, text, width = 100):
#        
#        
#        min_width = fontManager.get_small_font().size()
#    
#        
#    def render
#    
#        pygame.draw.polygon(self.displaySurface,(16,16,48),
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)])
#        # Frame it all        
#        pygame.draw.polygon(self.displaySurface,self.borderColor,
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)],
#                            1)


class Menu():
    def __init__(self, title, items):
        self.title = title
        self.items = items
        self.index = 0
        #self.active = False
        
        self.rect = None
        self.item_y_offset = 0
        self.padding = 10
        self.side_padding = 40
        
        self.resize_and_center_on_screent()

        #self.center_on_screen()
        
    def resize_and_center_on_screent(self):

        # get largest item
        largest_item = 'Resume Game'
        largest_item_size = fontManager.get_default_font().size(largest_item)
        
        
        self.item_y_offset = largest_item_size[1] + self.padding * 2
        
        
        width = largest_item_size[0] + self.side_padding * 2
        height = (self.item_y_offset) *  (len(self.items) + 1) + self.padding
        
        self.rect = pygame.Rect(SCREEN_WIDTH / 2 - width / 2, SCREEN_HEIGHT / 2 - height / 2, width, height)
                                
    def center_on_screen(self):
        self.rect.left = SCREEN_WIDTH / 2 - self.rect.width / 2
        self.rect.top = SCREEN_HEIGHT / 2 - self.rect.height / 2
        
        
    def update(self):
        if K_UP in Globals.KeysUp:
            self.index -= 1
            if self.index < 0:
                self.index = len(self.items) - 1

        elif K_DOWN in Globals.KeysUp:
            self.index += 1
            if self.index == len(self.items):
                self.index = 0
                
        elif K_RETURN in Globals.KeysUp:     #TODO: Move this code to the menu manager. It should be in whichever class makes the menu items
            if self.items[self.index] == 'Resume Game':
                EventManager().post_event(EVENT_TYPE.PAUSE_LEVEL, False)
            elif self.items[self.index] == 'Restart Level':
                EventManager().post_event(EVENT_TYPE.RESTART_LEVEL)
            elif self.items[self.index] == 'Quit':
                EventManager().post_event(EVENT_TYPE.QUIT)
        
    def render(self):
        OFFSET_FROM_TITLE = 6
        
        # -- draw the background
        colour = (60, 60, 170)
        pygame.draw.rect(Globals.Screen, colour, self.rect, 0)
        
        # -- add the frame
        colour = (0, 0, 30)
        pygame.draw.polygon(Globals.Screen, colour,
                            [(self.rect.left, self.rect.top),
                             (self.rect.left, self.rect.bottom),
                             (self.rect.right, self.rect.bottom),
                             (self.rect.right, self.rect.top)], 1)
        
        pygame.draw.line(Globals.Screen, colour, (self.rect.left, self.rect.top + self.item_y_offset), (self.rect.right, self.rect.top + self.item_y_offset))
        
        # -- highlight hovered item
        colour = (200, 200, 200)
        
        start_y = self.rect.top + self.item_y_offset * self.index + self.item_y_offset + OFFSET_FROM_TITLE
        end_y = start_y + self.item_y_offset
        left = self.rect.left + 5
        right = self.rect.right - 5
        pygame.draw.polygon(Globals.Screen, colour,
                            [(left, start_y),
                             (left, end_y),
                             (right, end_y),
                             (right, start_y)])
        
        # -- print menu text
        y_pos = self.rect.top + self.padding        
        colour = (255, 255, 255)
        font = fontManager.get_default_font()

        text = font.render(self.title, 1, colour)
        textpos = text.get_rect(centerx=self.rect.centerx, top=y_pos)
        
        Globals.Screen.blit(text, textpos)
        
        y_pos += OFFSET_FROM_TITLE
        
        for i in xrange(len(self.items)):
            
                #color = (200, 0, 0)  # if i == self._index else (200, 200, 200)
                y_pos += self.item_y_offset
                text = font.render(self.items[i], 1, colour)
                textpos = text.get_rect(centerx=self.rect.centerx, top=y_pos)
                Globals.Screen.blit(text, textpos)
                
                
#                textpos.top = yPos
#                Globals.Screen.blit(text, textpos)
#                yPos += 40
                #color = (200, 0, 0) if i == self._index else (200, 200, 200)
                #text = font.render(self.items[i], 1, color)
        
        
        
#        BORDER = 2
#        border_rect = pygame.Rect(rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
#        
#        colour = (0, 0, 30)
#        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
#        colour = (60, 60, 170)
#        pygame.draw.rect(Globals.Screen, colour, rect, 0)
        
        
#        pygame.draw.polygon(self.displaySurface,(16,16,48),
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)])
#        # Frame it all        
#        pygame.draw.polygon(self.displaySurface,self.borderColor,
#                            [(0,0),(self.size[0]-1,0),(self.size[0]-1,self.size[1]-1),(0,self.size[1]-1)],
#                            1)
        
    
#class MenuManager():
#    def __init__(self):
#
#
#
#
#class InLevelMenu():
#    def __init__(self):
#        self._items = ['Resume game', 'New Game', 'Save Game', 'Load Game', 'Quit']
#        
#        # create a surface to paste the border onto
#        
#    def update(self):
#        pass
#    
#    def render(self):
#        rect = pygame.Rect(50, 50, 50, 50)
#        
#        BORDER = 2
#        border_rect = (rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
#        
#        colour = (0, 0, 30)
#        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
#        colour = (60, 60, 170)
#        pygame.draw.rect(Globals.Screen, colour, rect, 0)
#        
#        pass
#    

#class Menu(State):
#    def __init__(self):
#        self._index = 0
# 
#    def update(self):
#        #keys = pygame.key.get_pressed()
#    
#        #if K_RETURN in Globals.KeysUp:
#        #    Globals.StateManager.pushState(SelectLevelMenu())
#
#        if K_UP in Globals.KeysUp:
#            self._index -= 1
#            if self._index < 0:
#                self._index = len(self._items) - 1
#
#        elif K_DOWN in Globals.KeysUp:
#            self._index += 1
#            if self._index == len(self._items):
#                self._index = 0
#
#        #~ elif K_RETURN in KEYS_UP:
#            #~ stateManager.pushState(MenuSelectLevelState())
#
#    def render(self):
#        Globals.Screen.fill((159, 182, 205))
#        yPos = 150
#        font = pygame.font.Font(None, 36)
#        for i in xrange(len(self._items)):
#                color = (200, 0, 0) if i == self._index else (200, 200, 200)
#                text = font.render(self._items[i], 1, color)
#                textpos = text.get_rect(centerx=Globals.Screen.get_width()/2)
#                textpos.top = yPos
#                Globals.Screen.blit(text, textpos)
#                yPos += 40
                

    