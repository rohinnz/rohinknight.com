'''
Created on 16 Nov 2010

@author: Rohin
'''
def singleton(cls):
    instance_container = []
    def getinstance():
        if not len(instance_container):
            instance_container.append(cls())
        return instance_container[0]
    return getinstance
 
@singleton
class MyClass:
    def __init__(self):
        self.health = 200
        
tank1 = MyClass()
tank2 = MyClass()

print 'tank1 health: %d' % tank1.health
print 'tank2 health: %d' % tank2.health

tank1.health = 100

print 'tank1 health: %d' % tank1.health
print 'tank2 health: %d' % tank2.health