from collections import deque
from utils import *

'''
        Event Types


* move attempt
* moved          - Camera will listen for player movement
* create
* destroyed
* collision


GAME


LEVEL
    - RESET
    - LOADED

ENTITY
    - MOVE LEFT / RIGHT
    - JUMP
    - THROW ROCK
    - MOVED
    - DIE

SETTINGS
    - INTERPOLATION SET
    - 
    
CHEATS / DEBUGGING
    - GODMODE SET
    - FLY SET
    - NO CLIPPING SET
    - LEVEL WARP
    - ADD ENTITY
    - KILL ENTITY
    - RELOAD LEVEL
    - RESET BADDIES
    - RESET OBJECTS
    

'''

EVENT_TYPE = enum('EVENT_TYPE',
    'QUIT, \
    PAUSE_LEVEL, \
    LEVEL_STARTED, \
    RESTART_LEVEL, \
    PLAYER_MOVED, \
    PLAYER_KILLED, \
    LEFT_KEY_DOWN, \
    CHEATS_GODMODE, \
    CHEATS_FLY, \
    CHEATS_NOCLIPPING, \
    SETTINGS_CHANGED')

class Event(object):
    def __init__(self, type, data):
        self.type = type
        self.data = data
        
        
#TODO: Re-implement to prevent every listener getting notified for every event.
        
@singleton
class EventManager(object):          #This should be a singleton
    def __init__(self):
        self._event_queue = deque()
        self._listeners = []
        
    def post_event(self, type, data = None):
        self._event_queue.appendleft(Event(type, data))
        
    #def attach_listener(self, event_listener, event_types):
    def attach_listener(self, event_listener):
        self._listeners.append(event_listener)
        
    def detach_listener(self, event_listener):
        self._listeners.remove(event_listener)
    
    def process_events(self):
        try:
            event = self._event_queue.pop()
        except IndexError:
            return
        
        for listener in self._listeners:
            listener.notify(event)
        
class EventListener(object):
    def notify(self, event):
        pass
