'''
Created on 13 Dec 2010

@author: Rohin
'''

'''
#TODO: DOCUMENT EVERYTHING!!!
#TODO: Try and simplify code        
#TODO: Base position off player, rather than camera.
 
class Parallax(object):
    def __init__(self):
        self.image = load_image(GFX_FILES['parallax'])
        self.rect = pygame.Rect(0, 0, self.image.get_width(), self.image.get_height())
        #self.dx = 0
        #self.dy = 0
        
    def update(self, camera):        
        new_pos = camera.rect.left * 0.7        
        self.rect.left = new_pos + int((camera.rect.left - new_pos) / self.rect.width) * self.rect.width
        
    def render(self, camera, use_interpolation = True):
        
        x = self.rect.left
        
        if use_interpolation:
            x += camera.dx_interpolate * 0.7

        cam_x = camera.rect.left + camera.dx_interpolate
        
        gap_to_fill = (camera.rect.right + camera.dx_interpolate) - (x + self.rect.width)
        
        num_extra_images = int(gap_to_fill / self.rect.width)
        
        last_gap = math.ceil(gap_to_fill % self.rect.width)    # Round up to nearest whole number to get the true width of the final gap to close off
        
        if last_gap != 0:
            num_extra_images += 1
        
#        if gap_to_fill > 0:
#            num_extra_images = int(gap_to_fill / self.rect.width)
#        
#            last_gap = math.ceil(gap_to_fill % self.rect.width)    # Round up to nearest whole number to get the true width of the final gap to close off
#        
#            if num_extra_images > 0 and last_gap != 0:
#                num_extra_images += 1
#        else:
#            num_extra_images = 0
#            last_gap = 0
        
#        if num_extra_images > 0 and gap_to_fill % self.rect.width != 0:
#            num_extra_images += 1
        
        
        #print 'gap to fill: %d' % gap_to_fill
        
        x_temp = x
        x -= cam_x
        y = self.rect.top    # + camera.dy_interpolate
        

        #Globals.Screen.blit(self.image, (x, y))    #TODO: crop out-of-camera part of image
        
        offset_x = cam_x - x_temp
        
        Globals.Screen.blit(self.image, (0, y), (offset_x, 0, self.rect.width - offset_x, self.rect.height))    #TODO: crop out-of-camera part of image
        
        for i in xrange(num_extra_images):
            x = x + self.rect.width
            
            if i + 1 == num_extra_images and last_gap != 0:
                #right_offset_x = (camera.rect.right + camera.dx_interpolate) - x - 50
                
                #last_gap = camera.rect.right + camera.dx_interpolate - x - 50
                
                Globals.Screen.blit(self.image, (x, y), (0, 0, last_gap, self.rect.height))
            else:
                Globals.Screen.blit(self.image, (x, y))      #TODO: crop out-of-camera part of image
        
#        if cam_x + camera.rect.width > x + self.rect.width:
#            x = x + self.rect.width
#            Globals.Screen.blit(self.image, (x, y))
#        if use_interpolation:
#            x = (camera.rect.left + camera.dx_interpolate) * 0.7
#        else:
#            x = self.rect.left
#
#        cam_x = camera.rect.left + camera.dx_interpolate
#        x -= cam_x
#        y = self.rect.top    # + camera.dy_interpolate
#        
#
#        Globals.Screen.blit(self.image, (x, y))       # This is really bad. We should only blit what is visible to the camera
#        
#        if cam_x + camera.rect.width > x + self.rect.width:
#            x = x + self.rect.width
#            Globals.Screen.blit(self.image, (x, y))

'''