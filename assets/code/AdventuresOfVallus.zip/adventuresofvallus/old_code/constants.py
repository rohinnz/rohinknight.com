'''
Created on 12 Oct 2010

@author: Rohin
'''

USE_INTERPOLATION = True
TICKS_PER_SECOND = 25
MAX_FPS = 0
CLOCK_USE_WAIT = True
MAX_FRAME_SKIP = 5

#        self.MAX_WAVES = 4
#        self.MAX_LEVELS = 30
#        self.WAVE_TARGET_POINTS = ( 70, 80, 90, 100 )
#        self.MAX_FALLING_KANA = ( 3, 4, 5, 3 )
#        self.KANA_SPEED = ( 1, 1, 1, 2 )
#        self.KANA_COLUMNS = 6
#        self.POINT_INCREMENT = 5
#        self.POINT_DECREMENT = 10