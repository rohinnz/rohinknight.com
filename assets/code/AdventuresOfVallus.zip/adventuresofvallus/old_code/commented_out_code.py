'''
Created on 4 Nov 2010

@author: Rohin

'''

'''
    def handle_input(self):
        
        
        # Check influence messages. Do not read directly from controls!!!!!
        
        
        keysdown = pygame.key.get_pressed()
        #eventManager = EventManager()
        
        if K_ESCAPE in Globals.KeysUp:
            #self.menu.active = not self.menu.active
            self.paused = not self.paused
            Timer.pause_all_timers(self.paused)
            
        if not self.paused:
            if keysdown[self.gamekeys.keys[JUMP]]:
                if self.player.grounded or self.cheats_fly:
                    self.player.dy = -JUMP_DIST
                    self.player.grounded = False
                        
            if keysdown[self.gamekeys.keys[MOVE_LEFT]]:                
                self.player.dx = -PLAYER_SPEED
            elif keysdown[self.gamekeys.keys[MOVE_RIGHT]]:
                self.player.dx = PLAYER_SPEED
            else:                
                self.player.dx = 0
                
            if K_SPACE in Globals.KeysUp:
                self.player_throw_rock()
                
        # END OF if not self.paused:
                
                
        if K_i in Globals.KeysUp:
            Globals.Use_Interpolation = not Globals.Use_Interpolation
            
        if K_g in Globals.KeysUp:
            self.cheats_godmode = not self.cheats_godmode

        if K_f in Globals.KeysUp:
            self.cheats_fly = not self.cheats_fly
            
        if K_c in Globals.KeysUp:
            self.cheats_noclipping = not self.cheats_noclipping

#        if K_r in Globals.KeysUp:            
#            self.cheats_rapid_speed = not self.cheats_rapid_speed
#            
#        if K_s in Globals.KeysUp:
#            tps = Globals.Clock.ticks_per_second
#                        
#            if tps >= 100:
#                tps = 5
#            else:
#                tps += 5
#                        
#            Globals.Clock.ticks_per_second = tps
        '''
'''
'''
        use_interpolation = False
        if Globals.Use_Interpolation and self.state == PLAYING and not self.paused:
            use_interpolation = True
            self.camera.calculate_interpolation()
        else:
            self.camera.dx_interpolate = 0
            self.camera.dy_interpolate = 0
            
        # -- Render everything
        Globals.Screen.fill(COLOR_SKY_BLUE)
        self.parallax_background.render(self.camera, use_interpolation)
        
        if self.state in (PLAYING, GAME_OVER, PLAYER_WINS):
            self.render_layers(self.camera, use_interpolation)
            self.player.render(self.camera, use_interpolation) 
            
            
            for rock in self.enemy_projectiles:
                rock.render(self.camera, use_interpolation)
            
            for baddie in self.baddies:
                baddie.render(self.camera, use_interpolation)    
            
#            self.update_messages()
#            if self.brief_message != False and self.brief_message.valid:
#                self.brief_message.render(self.camera)
            
            if not self.run_msg_delay.is_time_up():
                print_text(self.camera, 'RUN!')
            
        if self.state == GAME_OVER:
            print_text(self.camera, 'YOU ARE DEAD!')
            
        elif self.state == PLAYER_WINS:
            print_text(self.camera, 'YOU WIN!')
        else:
            if self.paused:
                self.menu.render()

    def tmp_draw_shapes(self, camera):
    
        rect = pygame.Rect(50, 50, 50, 50)
        
        BORDER = 2
        border_rect = (rect.left - BORDER, rect.top - BORDER, rect.width + BORDER * 2, rect.height + BORDER * 2)
        
        colour = (0, 0, 30)
        pygame.draw.rect(Globals.Screen, colour, border_rect, 0)
        colour = (60, 60, 170)
        pygame.draw.rect(Globals.Screen, colour, rect, 0)
        

        
        #pointlist = ((20, 20), (20, 40), (40, 40), (40, 20))
        
        #pygame.draw.polygon(Globals.Screen, colour, pointlist, 0)
              
        #colour = (0, 200, 0)
        #pygame.draw.aaline(Globals.Screen, colour, (20, 20, 4), (300, 300, 4), 1)
        


class Rock(pygame.sprite.Sprite):
    def __init__(self, x, y, dx, dy):
        pygame.sprite.Sprite.__init__(self)
        tmp_image = load_image(GFX_FILES['rock'])
        self.image = spriteimage(tmp_image)
        self.rect = pygame.Rect(x, y, self.image.get_width(), self.image.get_height())
        self.dx = dx
        self.dy = dy
    
    def render(self, camera, use_interpolation = True):
        x = self.rect.left - (camera.rect.left + camera.dx_interpolate)
        y = self.rect.top - (camera.rect.top + camera.dy_interpolate)
        
        
        if use_interpolation:
            x += self.dx * Globals.Clock.interpolate()
            y += self.dy * Globals.Clock.interpolate()
        
        Globals.Screen.blit(self.image, (x, y))
        
class Baddie(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        tmp_image = load_image(GFX_FILES['baddie'])
        self.image = spriteimage(tmp_image)
        self.rect = pygame.Rect(x, y, self.image.get_width(), self.image.get_height())
        self.dx = 0
        self.dy = 0
        self.grounded = False
        self.baddie_throw_delay = Timer(2000)
        
    def render(self, camera, use_interpolation = True):
        x = self.rect.left - (camera.rect.left + camera.dx_interpolate)
        y = self.rect.top - (camera.rect.top + camera.dy_interpolate)
        
        #use_interpolation = False
        if use_interpolation:
            x += self.dx * Globals.Clock.interpolate()
            y += self.dy * Globals.Clock.interpolate()
        
        Globals.Screen.blit(self.image, (x, y))
        '''

# --- CAMERA CLASS ---

#        if self.rect.centerx + dx < self.rect.width / 2:
#            dx = self.rect.width / 2 - self.rect.centerx
#        elif self.rect.centerx + dx > self.world_rect.width - (self.rect.width / 2):
#            dx = self.world_rect.width - (self.rect.width / 2) - self.rect.centerx
#            
#        if self.rect.centery + dy < self.rect.height / 2:
#            dy = self.rect.height / 2 - self.rect.centery
#        elif self.rect.centery + dy > self.world_rect.height - (self.rect.height / 2):
#            dy = self.world_rect.height - (self.rect.height / 2) - self.rect.centery
        
#        self.rect.centerx += dx
#        self.rect.centery += dy
        
        
        
        # DO IT ONCE MORE FOR INPOLATION!   --- will put it in a function soon. Promise
        
#        dx = player.dx
#        dy = player.dy
#        
#        
#        if self.rect.left + dx < 0:
#            dx = self.rect.left
#        elif self.rect.right + dx > self.world_rect.width:
#            dx = self.world_rect.width  - self.rect.right
#            
#        if self.rect.top + dy < 0:
#            dy = self.rect.top
#        elif self.rect.top + dy > self.world_rect.height:
#            dy = self.world_rect.height - self.rect.top
#            
#        self.dx = dx
#        self.dy = dy
#        
#        
#        print 'cam.dx %d' % dx
#        print 'cam.dy %d' % dy
        
        
        # -- Apply dx and dy

        #self.dx = 0
        #self.dy = 0
        
        # -- Calculate new dx and dy
#        SCROLL_OFFSET = 0
#        SCROLL_OFFSET_DOWN = 40
#        SCROLL_OFFSET_UP = 200
        
#        self.x = self.rect.left
#        self.y = self.rect.top
        
#        if player_rect.centerx > self.rect.centerx:
#            dx = player_rect.centerx - self.rect.centerx
#        elif player_rect.centerx < self.rect.centerx:
#            dx = player_rect.centerx - self.rect.centerx
#        if player_rect.centery > self.rect.centery:
#            dy = player_rect.centery - self.rect.centery
#        elif player_rect.centery < self.rect.centery:
#            dy = player_rect.centery - self.rect.centery

        #self.rect.clamp_ip(self.world_rect)    #Ensure the whole cam is inside the world rect


#        if self.flash:
        #redimg = surfarray.array3d(self.image)
#        redimg = array(rgbarray)
        #redimg[:,:,1:] = 0
#        flipped = rgbarray[:,::-1]
#        striped = zeros((self.rect.width, self.rect.height, 3))
#        striped[:] = (255, 0, 0)
#        striped[:,::3] = (0, 255, 255)
#        self.image = surfarray.make_surface(striped)

#class Menu(State):
#    def __init__(self):
#        self._index = 0
# 
#    def update(self):
#        #keys = pygame.key.get_pressed()
#    
#        #if K_RETURN in Globals.KeysUp:
#        #    Globals.StateManager.pushState(SelectLevelMenu())
#
#        if K_UP in Globals.KeysUp:
#            self._index -= 1
#            if self._index < 0:
#                self._index = len(self._items) - 1
#
#        elif K_DOWN in Globals.KeysUp:
#            self._index += 1
#            if self._index == len(self._items):
#                self._index = 0
#
#        #~ elif K_RETURN in KEYS_UP:
#            #~ stateManager.pushState(MenuSelectLevelState())
#
#    def render(self):
#        Globals.Screen.fill((159, 182, 205))
#        yPos = 150
#        font = pygame.font.Font(None, 36)
#        for i in xrange(len(self._items)):
#                color = (200, 0, 0) if i == self._index else (200, 200, 200)
#                text = font.render(self._items[i], 1, color)
#                textpos = text.get_rect(centerx=Globals.Screen.get_width()/2)
#                textpos.top = yPos
#                Globals.Screen.blit(text, textpos)
#                yPos += 40
#    
#class MainMenu(Menu):
#    def __init__(self):
#        Menu.__init__(self)
#        self._items = ['Play', 'Instructions', 'Options', 'Credits', 'Exit']
#
#    def update(self):
#        Menu.update(self)
#
#        if K_RETURN in Globals.KeysUp:
#            if self._items[self._index] == 'Play':
#                Globals.StateManager.pushState(SelectDifficultyMenu())
#            if self._items[self._index] == 'Instructions':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Options':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Credits':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Exit':
#                Globals.StateManager.pushState(SelectLevelMenu())
#
#    def render(self):
#        Menu.render(self)
#        
##--------------------------------------------------------------------------------------------------------------------------------------------------
#class SelectDifficultyMenu(Menu):  #TODO: Connect this menu state up to the game.
#    def __init__(self):
#        Menu.__init__(self)
#        self._items = ['Easy', 'Normal', 'Hard', 'INSANE']
#
#    def update(self):
#        Menu.update(self)
#
#        if K_RETURN in Globals.KeysUp:
#            difficulty = self._items[self._index]
#            Globals.StateManager.pushState(Level(difficulty))
#
#    def render(self):
#        Menu.render(self)
        

#        if use_interpolation:
#            x += camera.dx_interpolate + self.dx * Globals.Clock.interpolate()
#            y += camera.dy_interpolate + self.dy * Globals.Clock.interpolate()
        
        
        
#        x = self.rect.left - camera.rect.left - self.tmp_offset_x + (self.dx * Globals.Clock.interpolate())
#        y = self.rect.top - camera.rect.top + (self.dy * Globals.Clock.interpolate())
#        Globals.Screen.blit(self.images[self.frame], (x, y))
        
#        if self.sick:            #TODO: This should be precalculated!
#            redimg_array = surfarray.array3d(self.images[self.frame])
#            redimg_array[:,:,1:] = 0
#            redimg = surfarray.make_surface(redimg_array)
#            redimg.set_colorkey((0,0,0))
#            redimg.convert_alpha()
#            Globals.Screen.blit(redimg, (x, y))
#        else:
#            Globals.Screen.blit(self.images[self.frame], (x, y))

        #=======================================================================
        # DO SOME MATHS
        #=======================================================================
        
        # -- Calculate angle
        
        #SOHCAHTOA
        
        # Get the angle in rads
        
#        angle = math.atan(DY/DX)
#        
#        # Get the velocity
#        velocity = math.sqrt(DX**2 + DY**2)
#        
#        range = (velocity**2 * math.sin(2 * angle)) / GRAVITY_SPEED
#        
#        
#        velocity2 = math.sqrt((range * GRAVITY_SPEED) /  math.sin(2 * angle))
#        
#        
#        newYVelocity = math.sin(angle) * velocity2
                #===============================================================
                # Throw rock at player
                #===============================================================
#                angle = math.atan(DY/DX)
#        
#                # Get the velocity
#                velocity = math.sqrt(DX**2 + DY**2)
#        
#                range = (velocity**2 * math.sin(2 * angle)) / GRAVITY_SPEED
            
#        FROM_TILE_X = camera.rect.left / TILE_WIDTH
#        FROM_TILE_Y = camera.rect.top / TILE_HEIGHT
#        TO_TILE_X =  camera.rect.right / TILE_WIDTH + 1
#        TO_TILE_Y = camera.rect.bottom / TILE_HEIGHT + 1
#        TILE_OFFSET_X = camera.rect.left % TILE_WIDTH
#        TILE_OFFSET_Y = camera.rect.top % TILE_HEIGHT
        
        

#            if MOVE_LEFT in Globals.KeysDown:
#                self.player.dx = -PLAYER_SPEED
#            elif MOVE_LEFT in Globals.KeysUp:
#                self.player.dx = 0
#                
#            if MOVE_RIGHT in Globals.KeysDown:
#                self.player.dx = PLAYER_SPEED
#            elif MOVE_RIGHT in Globals.KeysUp:
#                self.player.dx = 0
                

#--------------------------------------------------------------------------------------------------------------------------------------------------
#SPEED = 10
#PLAYING, GAME_OVER, PLAYER_WINS = range(3)
#
#GRAVITY_SPEED = 2
#MAX_FALL_SPEED = 25
#PLAYER_SPEED = 8
#JUMP_DIST = 30
#
#TILE_WIDTH = 32
#TILE_HEIGHT = 32
#
##JUMP, MOVE_LEFT, MOVE_RIGHT, THROW_ROCK = 0, 1, 2, 3
#JUMP, MOVE_LEFT, MOVE_RIGHT = 0, 1, 2

#        if self.player.x > SCREEN_WIDTH - FORCE_SCROLL_DISTANCE:
#            self.cam_offset_x -= SPEED
#        elif self.player.x < FORCE_SCROLL_DISTANCE:
#            self.cam_offset_x += SPEED
#        if self.player.y > SCREEN_HEIGHT - FORCE_SCROLL_DISTANCE:
#            self.cam_offset_y -= SPEED
#        elif self.player.y < FORCE_SCROLL_DISTANCE:
#            self.cam_offset_y += SPEED
#        pass

#        if player_rect.centerx > self.rect.l:
#            self.dx = player_rect.centerx - self.rect.centerx
#        elif player_rect.centerx < self.rect.centerx:
#            self.dx = player_rect.centerx - self.rect.centerx
#        if player_rect.centery > self.rect.centery:
#            self.dy = player_rect.centery - self.rect.centery
#        elif player_rect.centery < self.rect.centery:
#            self.dy = player_rect.centery - self.rect.centery

#        if player_rect.centerx > self.rect.centerx+SCROLL_OFFSET:
#            self.dx = player_rect.centerx - (self.rect.centerx + SCROLL_OFFSET)
#        if player_rect.centerx < self.rect.centerx-SCROLL_OFFSET:
#            self.dx = player_rect.centerx - (self.rect.centerx - SCROLL_OFFSET)
#        if player_rect.centery > self.rect.centery+SCROLL_OFFSET_DOWN:
#            self.dy = player_rect.centery - (self.rect.centery + SCROLL_OFFSET_DOWN)
#        if player_rect.centery < self.rect.centery-SCROLL_OFFSET_UP:
#            self.dy = player_rect.centery + (self.rect.centery - SCROLL_OFFSET_UP)
        
#        if player_rect.centerx > self.rect.centerx+SCROLL_OFFSET:
#            self.rect.centerx = player_rect.centerx-SCROLL_OFFSET
#        if player_rect.centerx < self.rect.centerx-SCROLL_OFFSET:
#            self.rect.centerx = player_rect.centerx+SCROLL_OFFSET
#        if player_rect.centery > self.rect.centery+SCROLL_OFFSET_DOWN:
#            self.rect.centery = player_rect.centery-SCROLL_OFFSET_DOWN     
#        if player_rect.centery < self.rect.centery-SCROLL_OFFSET_UP:
#            self.rect.centery = player_rect.centery+SCROLL_OFFSET_UP
#class MainMenu(Menu):  #TODO: Modify to inherit from Menu
#    def __init__(self):
#        Menu.__init__(self)
#        self._items = ['Play', 'Instructions', 'Options', 'Credits', 'Exit']
#
#    def update(self):
#        Menu.update(self)
#
#        if K_RETURN in Globals.KeysUp:
#            if self._items[self._index] == 'Play':
#                Globals.StateManager.pushState(SelectDifficultyMenu())
#            if self._items[self._index] == 'Instructions':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Options':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Credits':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Exit':
#                Globals.StateManager.pushState(SelectLevelMenu())
#
#    def render(self):
#        Menu.render(self)
#        
##--------------------------------------------------------------------------------------------------------------------------------------------------
#class SelectDifficultyMenu(Menu):  #TODO: Connect this menu state up to the game.
#    def __init__(self):
#        Menu.__init__(self)
#        self._items = ['Easy', 'Normal', 'Hard', '(maybe) Impossible']
#
#    def update(self):
#        Menu.update(self)
#
#        if K_RETURN in Globals.KeysUp:
#            if self._items[self._index] == 'Easy':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Normal':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == 'Hard':
#                Globals.StateManager.pushState(SelectLevelMenu())
#            if self._items[self._index] == '(Maybe) Impossible':
#                Globals.StateManager.pushState(SelectLevelMenu())
#        
#    def render(self):
#        Menu.render(self)
#
#class SelectLevelMenu(Menu):
#    def __init__(self):
#        Menu.__init__(self)
#        
#        self._items = []
#        for i in xrange(1, 31):
#            self._items.append("Level %s" % i)
#
#    def update(self):
#        Menu.update(self)
#        
##        if K_UP in Globals.KeysUp:
##            self._index -= 1
##            if self._index < 0:
##                self._index = len(self.menu_items) - 1
##
##        elif K_DOWN in Globals.KeysUp:
##            self._index += 1
##            if self._index == len(self.menu_items):
##                self._index = 0
#
#        if K_RETURN in Globals.KeysUp:
#            Globals.StateManager.pushState(Level(self._index + 1))
#            #self.engine.stateManager.pushState(MenuSelectLevelState(self.engine))
#
#        elif K_ESCAPE in Globals.KeysUp:
#            Globals.StateManager.popState()
#
#    def render(self):
#        Globals.Screen.fill((159, 182, 205))
#
#        ypos = 50
#        font = pygame.font.Font(None, 36)
#
#        centerx = Globals.Screen.get_width() / 2
#
#        xpos = centerx - 200
#
##        xpos = [centerx - 30, centerx. centerx + 30]
#
#        for i in xrange(len(self._items)):
#            color = (200, 0, 0) if i == self._index else (200, 200, 200)
#            text = font.render(self._items[i], 1, color)
#            textpos = text.get_rect(centerx = xpos)
#            textpos.top = ypos
#            Globals.Screen.blit(text, textpos)
#            ypos += 40
#
#            if (i + 1) % 10 == 0:
#                xpos += 200
#                ypos = 50
##--------------------------------------------------------------------------------------------------------------------------------------------------
#class Credits(State):
#    def update(self):
#        pass
#
#    def render(self):
#        pass
##--------------------------------------------------------------------------------------------------------------------------------------------------
#class Instructions(State):
#    def update(self):
#        pass
#
#    def render(self):
#        pass

#-------------------------------------------------------------------------------------------------------------------------------------------------
#class AnimatedSprite(pygame.sprite.Sprite):
#    def __init__(self, images, animations = {}, fps = 10):
#        pygame.sprite.Sprite.__init__(self)
#        self._images = images
#        self._animations = animations
#        self._animSequence = animations.itervalues().next()  # Get first element
#
#
#        # Track the time we started, and the time between updates.
#        # Then we can figure out when we have to switch the image.
#        self._start = pygame.time.get_ticks()
#        self._delay = 1000 / fps
#        self._last_update = 0
#        self._frame = 0
#
#        # Call update to set our first image.
#        self.update(pygame.time.get_ticks())
#
#    def update(self, t):
#        # Note that this doesn't work if it's been more that self._delay
#        # time between calls to update(); we only update the image once
#        # then, but it really should be updated twice.
#
#        if t - self._last_update > self._delay:
#            self._frame += 1
#            if self._frame >= len(self._animSequence): self._frame = 0
#            self.image = self._images[self._frame]
#            self._last_update = t
#            
#    def setAnimation(self, name):
#        self._currAnimation = self._animations[name]

#        if self.gamekeys.keys[THROW_ROCK] in Globals.KeysDown:
#            self.throw_rock()
        
#        if keysdown[K_UP]:
#            if self.player.grounded:
#                self.player.dy = -JUMP_DIST
#                self.player.grounded = False
#            
#        if keysdown[K_LEFT]:
#            self.player.dx -= PLAYER_SPEED
#            
#        if keysdown[K_RIGHT]:
#            self.player.dx += PLAYER_SPEED

#    def baddie_throw_rock(self, baddie):
#        xpos = baddie.rect.left
#        ypos = baddie.rect.top
#        
#    
#        #    http://en.wikipedia.org/wiki/Range_of_a_projectile
#    
#        angle = deg2rad(45)  #Always throw at 45 degrees
#        range = self.player.rect.left - baddie.rect.left
#        
#        
#        y_distance = (baddie.rect.top + baddie.rect.height) - (self.player.rect.top + self.player.rect.height)
#        
#        velocity_xy = math.sqrt((range * GRAVITY_SPEED) /  math.sin(2 * angle))
#        
#        velocity_x = math.cos(angle) * velocity_xy
#        velocity_y = math.sin(angle) * velocity_xy
#                
#        self.rocks.append(Rock(xpos, ypos, velocity_x, -velocity_y))
#        
#        
#        # Test calculation
#        
#        distance = ((velocity_xy * math.cos(angle) / GRAVITY_SPEED) * (velocity_xy * math.sin(angle) + math.sqrt((velocity_xy * math.sin(angle))**2 + 2 * GRAVITY_SPEED * y_distance )))
#        
#        pause = True

#--------------------------------------------------------------------------------------------------------------------------------------------------
#def printMessage(text, text2 = None):
#    font = pygame.font.Font(None, 28)
#    color = (0, 80, 0)
#    sur_text = font.render(text, 1, color)
#    textpos = sur_text.get_rect(centerx=Globals.Screen.get_width()/2, centery=Globals.Screen.get_height()/2 - 13)
#    Globals.Screen.blit(sur_text, textpos)
#    
#    if text2 != None:
#        sur_text2 = font.render(text2, 1, color)
#        textpos = sur_text2.get_rect(centerx=Globals.Screen.get_width()/2, centery=Globals.Screen.get_height()/2 + 13)
#        Globals.Screen.blit(sur_text2, textpos)



#def rad2deg(radians):
#    pi = math.pi
#    degrees = 180 * radians / pi
#    return degrees
#def deg2rad(degrees):
#    pi = math.pi
#    radians = pi * degrees / 180
#    return radians

#    def baddie_throw_rock(self, baddie):
#        xpos = baddie.rect.left
#        ypos = baddie.rect.top
#        
#    
#        #    http://en.wikipedia.org/wiki/Range_of_a_projectile
#    
#        angle = deg2rad(45)  #Always throw at 45 degrees
#        range = self.player.rect.left - baddie.rect.left
#        
#        
#        y_distance = (baddie.rect.top + baddie.rect.height) - (self.player.rect.top + self.player.rect.height)
#        
#        velocity_xy = math.sqrt((range * GRAVITY_SPEED) /  math.sin(2 * angle))
#        
#        velocity_x = math.cos(angle) * velocity_xy
#        velocity_y = math.sin(angle) * velocity_xy
#                
#        self.rocks.append(Rock(xpos, ypos, velocity_x, -velocity_y))
#        
#        
#        # Test calculation
#        
#        distance = ((velocity_xy * math.cos(angle) / GRAVITY_SPEED) * (velocity_xy * math.sin(angle) + math.sqrt((velocity_xy * math.sin(angle))**2 + 2 * GRAVITY_SPEED * y_distance )))
#        
#        pause = True

#                #===============================================================
#                # Do tile clipping
#                #===============================================================
#                # -- First check if we can move left or right
#                new_x = baddie.rect.left + baddie.dx
#                tile_x, tile_y, img_idx = self.get_collision_solid_tile(new_x, baddie.rect.top, baddie)
#                
#                if img_idx == False:
#                    baddie.rect.left = new_x
#                else:
#                        # line up with the tile boundary
#                    if baddie.dx > 0:
#                        baddie.rect.left = (tile_x * TILE_WIDTH) - baddie.rect.width
#                        baddie.dx = -4
#                    elif baddie.dx < 0:
#                        baddie.rect.left = (tile_x * TILE_WIDTH) + TILE_WIDTH
#                        baddie.dx = 4
#
#                #First check if we are on a platform
#                new_y = baddie.rect.top + baddie.dy
#                on_platform = False
#                
#                if baddie.dy > 0:
#                    tile_x, tile_y, img_idx = self.get_collision_platform_tile(baddie.rect.left, new_y, baddie)
#                    
#                    if img_idx != False:
#                        on_platform = True
#                        baddie.rect.top = (tile_y * TILE_HEIGHT) - baddie.rect.height - 1
#                        baddie.grounded = True
#                        baddie.dy = 0
#
#                #IF we aren't on a platform, then check if we are on a solid
#                if on_platform == False:
#                    tile_x, tile_y, img_idx = self.get_collision_solid_tile(baddie.rect.left, new_y, baddie)
#                
#                    if img_idx == False:
#                        baddie.rect.top = new_y
#                        baddie.grounded = False
#                    else:                                                            # line up with the tile boundary
#                        if baddie.dy > 0:
#                            baddie.grounded = True
#                            baddie.rect.top = (tile_y * TILE_HEIGHT) - baddie.rect.height 
#                        elif baddie.dy < 0:
#                            baddie.rect.top = (tile_y * TILE_HEIGHT) + TILE_HEIGHT    
#                        baddie.dy = 0
#                            
#                #===============================================================
#                # Do screen boundary clipping
#                #===============================================================
#                if baddie.rect.left < 0:                                                                   
#                    baddie.rect.left = 0
#                elif baddie.rect.left > self.map_width - baddie.rect.width:
#                    baddie.rect.left = self.map_width - baddie.rect.width
#                if baddie.rect.top < 0:                                                              
#                    baddie.rect.top = 0
#                    baddie.dy = 0
#                elif baddie.rect.top > self.map_height - baddie.rect.height: 
#                    baddie.rect.top = self.map_height - baddie.rect.height
#                    baddie.grounded = True

                
                
                
                '''
                    
        # -- Second check if we can move up or down
        new_y = self.player.rect.top + self.player.dy
        tile_x, tile_y, img_idx = self.get_collision_solid_tile(self.player.rect.left, new_y)
        
        if img_idx == False:
            #Now check for a collision with a platform
            
                                                                #TODO: Need to move this test outside to fix bug where player can fall through platform after leaving solid!
                                                                #TODO: Another bug to fix is when leaving a platform, gravity is too strong!
            tile_x, tile_y, img_idx = self.get_collision_platform_tile(self.player.rect.left, new_y)
            
            if img_idx == False:
                self.player.rect.top = new_y
                self.player.grounded = False            
            else:
                if self.player.dy > 0:
                    self.player.rect.top = (tile_y * TILE_HEIGHT) - self.player.rect.height - 1
                    self.player.grounded = True
                    self.player.dy = 0
                else:
                    self.player.rect.top = new_y
                    self.player.grounded = False
            
        else:                  # line up with the tile boundary
            if self.player.dy > 0:
                    self.player.grounded = True
                    self.player.rect.top = (tile_y * TILE_HEIGHT) - self.player.rect.height
                     
            elif self.player.dy < 0:
                self.player.rect.top = (tile_y * TILE_HEIGHT) + TILE_HEIGHT    
            self.player.dy = 0
            
            
            
    def get_collision_solid_tile(self, new_x, new_y, entity):   # You cannot pass through a solid tile
        from_x = min(self.player.rect.left, new_x)
        from_y = min(self.player.rect.top, new_y)
        to_x = max(self.player.rect.left, new_x)
        to_y = max(self.player.rect.top, new_y)
        
        TILE_WIDTH = self.map.tilewidth
        TILE_HEIGHT = self.map.tileheight

        FROM_TILE_X = from_x / TILE_WIDTH
        FROM_TILE_Y = from_y / TILE_HEIGHT
        
        TO_TILE_X =  (to_x + self.player.rect.width - 1) / TILE_WIDTH + 1
        TO_TILE_Y = (to_y + self.player.rect.height - 1) / TILE_HEIGHT + 1
        
        if FROM_TILE_X < 0:
            FROM_TILE_X = 0
        
        if FROM_TILE_Y < 0:
            FROM_TILE_Y = 0
            
        if TO_TILE_X > self.map.width:
            TO_TILE_X = self.map.width
        
        if TO_TILE_Y > self.map.height:
            TO_TILE_Y = self.map.height
            

        #perform bounds checking on 
            
        # -- All layers are treated as visible
        for layer in self.map.layers[:]:
            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):

                    img_idx = layer.content2D[xpos][ypos]      
                    
                    #if img_idx:
                    if img_idx and img_idx in self.indexed_tiles:       # -- Check for collision
                        tile = self.indexed_tiles[img_idx]
                        
                        if 'solid' in tile.properties:
                            return (xpos, ypos, img_idx)

        return (0, 0, False) 
'''


#        #==========================
#        # Handle Gravity
#        #==========================
#        self.player.dy += GRAVITY_SPEED
#        
#        if self.player.dy > MAX_FALL_SPEED:
#            self.player.dy = MAX_FALL_SPEED
#        #==========================
#        # -- Check tile bounds --        
#        #==========================
#
#        #dx = self.player.dx
#        #dy = self.player.dy
#        
#        # -- First check if we can move left or right
#        new_x = self.player.rect.left + self.player.dx
#        tile_x, tile_y, img_idx = self.get_collision_solid_tile(new_x, self.player.rect.top, self.player)
#        
#        if img_idx == False:
#            self.player.rect.left = new_x
#        else:
#                # line up with the tile boundary
#            if self.player.dx > 0:
#                self.player.rect.left = (tile_x * TILE_WIDTH) - self.player.rect.width
#            elif self.player.dx < 0:
#                self.player.rect.left = (tile_x * TILE_WIDTH) + TILE_WIDTH
#
#
#
#        #=======================================================================
#        # Check up/down movement
#        #=======================================================================
#        
#        #First check if we are on a platform
#        new_y = self.player.rect.top + self.player.dy
#        on_platform = False
#        
#        if self.player.dy > 0:
#            tile_x, tile_y, img_idx = self.get_collision_platform_tile(self.player.rect.left, new_y, self.player)
#            
#            if img_idx != False:
#                on_platform = True
#                self.player.rect.top = (tile_y * TILE_HEIGHT) - self.player.rect.height - 1
#                self.player.grounded = True
#                self.player.dy = 0
#
#
#        #IF we aren't on a platform, then check if we are on a solid
#        if on_platform == False:
#            tile_x, tile_y, img_idx = self.get_collision_solid_tile(self.player.rect.left, new_y, self.player)
#        
#            if img_idx == False:
#                self.player.rect.top = new_y
#                self.player.grounded = False
#            else:                                                            # line up with the tile boundary
#                if self.player.dy > 0:
#                    self.player.grounded = True
#                    self.player.rect.top = (tile_y * TILE_HEIGHT) - self.player.rect.height 
#                elif self.player.dy < 0:
#                    self.player.rect.top = (tile_y * TILE_HEIGHT) + TILE_HEIGHT    
#                self.player.dy = 0
#    
#
#        #===========================
#        # -- Check screen bounds --
#        #===========================
#        if self.player.rect.left < 0:                                                        
#            self.player.rect.left = 0
#        elif self.player.rect.left > self.map_width - self.player.rect.width:
#            self.player.rect.left = self.map_width - self.player.rect.width
#        if    self.player.rect.top < 0:                                                        
#            self.player.rect.top = 0
#            self.player.dy = 0
#            
#        elif self.player.rect.top > self.map_height - self.player.rect.height: 
#            self.player.rect.top = self.map_height - self.player.rect.height
#            self.player.grounded = True
#            
#            
#        #===========================
#        # -- Update animation
#        #===========================
#        self.player.update()
#            
#        #===========================
#        # -- Apply friction
#        #===========================
#        # -- Asign 0 to dx to set fiction to maximum
#        
#        self.player.dx = 0
#        if self.player.dx > 0:
#            self.player.dx -= 1
#        elif self.player.dx < 0:
#            self.player.dx += 1


#        FROM_TILE_X = from_x / TILE_WIDTH
#        FROM_TILE_Y = from_y / TILE_HEIGHT
#        TO_TILE_X =  (to_x + entity.rect.width - 1) / TILE_WIDTH + 1
#        TO_TILE_Y = (to_y + entity.rect.height - 1) / TILE_HEIGHT + 1
#        
#        if FROM_TILE_X < 0:                        FROM_TILE_X = 0
#        elif TO_TILE_X > self.map.width:      TO_TILE_X = self.map.width
#        if FROM_TILE_Y < 0:                        FROM_TILE_Y = 0    
#        elif TO_TILE_Y > self.map.height:    TO_TILE_Y = self.map.height
#            
#        #perform bounds checking on 
#            
#        # -- All layers are treated as visible
#        for layer in self.map.layers[:]:
#            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
#                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):
#
#                    img_idx = layer.content2D[xpos][ypos]
#                    
#                    #if img_idx:
#                    if img_idx and img_idx in self.indexed_tiles:       # -- Check for collision
#                        tile = self.indexed_tiles[img_idx]
#                        
#                        if 'platform' in tile.properties:
#                            return (xpos, ypos, img_idx)
#
#        return (0, 0, False) 


#        from_x = min(entity.rect.left, new_x)
#        from_y = min(entity.rect.top, new_y)
#        to_x = max(entity.rect.left, new_x)
#        to_y = max(entity.rect.top, new_y)
#
#        FROM_TILE_X = from_x / TILE_WIDTH
#        FROM_TILE_Y = from_y / TILE_HEIGHT
#        TO_TILE_X =  (to_x + entity.rect.width - 1) / TILE_WIDTH + 1
#        TO_TILE_Y = (to_y + entity.rect.height - 1) / TILE_HEIGHT + 1
#        
#        if FROM_TILE_X < 0:                     FROM_TILE_X = 0
#        elif TO_TILE_X > self.map.width:    TO_TILE_X = self.map.width
#        if FROM_TILE_Y < 0:                     FROM_TILE_Y = 0
#        elif TO_TILE_Y > self.map.height:   TO_TILE_Y = self.map.height
#            
#        #perform bounds checking on 
#            
#        # -- All layers are treated as visible
#        for layer in self.map.layers[:]:
#            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
#                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):
#
#                    img_idx = layer.content2D[xpos][ypos]      
#                    
#                    #if img_idx:
#                    if img_idx and img_idx in self.indexed_tiles:       # -- Check for collision
#                        tile = self.indexed_tiles[img_idx]
#                        
#                        if 'solid' in tile.properties:
#                            return (xpos, ypos, img_idx)
#
#        return (0, 0, False) 

#    def render_layers(self):
#        from_tile_x = self.camera.rect.left / TILE_WIDTH
#        from_tile_y = self.camera.rect.top / TILE_HEIGHT
#            
#        num_tiles_x = self.camera.rect.width / TILE_WIDTH
#        num_tiles_y = self.camera.rect.height / TILE_HEIGHT
#        
#        tile_offset_x = self.camera.rect.left % TILE_WIDTH
#        tile_offset_y = self.camera.rect.top % TILE_HEIGHT
#            
#        # -- Check if we have an even number of tiles for the cam width. If not then add an extra tile.
#        if SCREEN_WIDTH % TILE_WIDTH != 0: 
#            num_tiles_x += 1
#        
#        if SCREEN_HEIGHT % TILE_HEIGHT != 0:
#            num_tiles_y += 1 
#        
#        
#        #TODO: Replace with simple bounds checking
#        
#        # -- If there is an offset, then we will need to add another tile (unless we are at the far right of the map)
#        if tile_offset_x != 0 and (from_tile_x + num_tiles_x) < self.map.width:
#            num_tiles_x += 1
#
#        # -- Same as above, except for the y axis
#        if tile_offset_y != 0 and (from_tile_y + num_tiles_y) < self.map.height:
#            num_tiles_y += 1
#        
#        # -- All layers are treated as visible
#        for layer in self.map.layers[:]:
#            for xpos in xrange(from_tile_x, from_tile_x + num_tiles_x):
#                for ypos in xrange(from_tile_y, from_tile_y + num_tiles_y):
#                    img_idx = layer.content2D[xpos][ypos]
#
#                    if img_idx:      # and img_idx in self.indexed_tiles:
#                        x = (xpos - from_tile_x) * TILE_WIDTH - tile_offset_x    # OR is it TILE_WIDTH - tile_offset_x ?????
#                        y = (ypos - from_tile_y) * TILE_HEIGHT - tile_offset_y
#                        offx, offy, screen_img = self.map.indexed_tile_images[img_idx]   #TODO: Find out what offx and offy are for. They can probably be removed from tiledtmxloader.py
#                        Globals.Screen.blit(screen_img, (x, y))   #TODO: Add extra calculations to avoid printing parts of tiles outside of screen (Very low priority)