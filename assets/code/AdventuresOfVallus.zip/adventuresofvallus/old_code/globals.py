#'''
#Created on 18 Oct 2010
#
#@author: Rohin
#'''
#
#
#from gameclock import *
#
##===============================================================================
## GLOBAL VARIABLES CLASS
##===============================================================================
#class Globals:
#    Screen = None
#    Clock = None
##    TimePassed = 0
##    CurrentTicks = 0
#    FPS = 0
#    KeysUp = []
#    KeysDown = []
#    StateManager = None
#    Use_Interpolation = True
#
#    MISC = {}       #We probably won't need this one
#        
##===============================================================================
## WINDOW
##===============================================================================
#TITLE = "KeySwap v0.1"
#
#SCREEN_WIDTH = 800
#SCREEN_HEIGHT = 600
#SCREEN_DIM = (SCREEN_WIDTH, SCREEN_HEIGHT)
#
#
##===============================================================================
## COLOURS
##===============================================================================
#COLOR_SKY_BLUE = (59, 185, 255)
#
##===============================================================================
## GAME LOOP DEFAULTS
##===============================================================================
#INTERPOLATION_ENABLED = False
#TICKS_PER_SECOND = 25
#MAX_FPS = 0                            #0 = Unlimited. We may need to set a max if trying to save CPU cycles
#CLOCK_USE_WAIT = True
#MAX_FRAME_SKIP = 5
#
#
##===============================================================================
## LEVEL
##===============================================================================
#PLAYING, GAME_OVER, PLAYER_WINS = range(3)
#JUMP, MOVE_LEFT, MOVE_RIGHT = range(3)
#
#GRAVITY_SPEED = 1
#MAX_FALL_SPEED = 10
#PLAYER_SPEED = 10
#JUMP_DIST = 16
#
#TILE_WIDTH = 32
#TILE_HEIGHT = 32
#
#
#RAPID_PLAYER_SPEED = 50
#RAPID_JUMP_DIST = 40
#RAPID_GRAVITY_SPEED = 4
#RAPID_MAX_FALL_SPEED = 20
#
##JUMP, MOVE_LEFT, MOVE_RIGHT, THROW_ROCK = 0, 1, 2, 3
#
##===============================================================================
## DATA FILES
##===============================================================================
#DATA_DIR = 'data/'
#SOUND_DIR = DATA_DIR + 'sound/'
#GFX_DIR = DATA_DIR + 'gfx/'
#LEVELS_DIR = DATA_DIR + 'levels/'
#FONTS_DIR = DATA_DIR + 'fonts/'
#
#GFX_FILES = {
#    'player': GFX_DIR + 'player.bmp',
#    'baddie': GFX_DIR + 'baddie.bmp',
#    'rock': GFX_DIR + 'rock.bmp',
#    'parallax': GFX_DIR + 'parallax.png',
#    'xxx bottle': GFX_DIR + 'xxx_bottle3.png'
#}
#
#FONT_FILES = {
#    'cactus': FONTS_DIR + 'cactus_plain.ttf'
#}
#
#LEVEL_FILES = {
#    'level1': LEVELS_DIR + 'level1.tmx'
#}
#
##SOUND_FILES = {
##    "pop": DATA_DIR + "sounds/pop.wav",
##    "error": DATA_DIR + "sounds/computerbeep2.wav"
##}
##
##IMAGE_FILE = {
##    "kana": DATA_DIR + "gfx/kana_2.png",
##    "playership" : DATA_DIR + "gfx/playership.png"
##}
#
#
##PLAYER_IMAGE = DATA_DIR + 'player.bmp'
##LEVEL_1_FILE = DATA_DIR + 'level1.tmx'
##ROCK_IMAGE = DATA_DIR +  'rock.bmp'
##BADDIE_IMAGE = DATA_DIR + 'baddie.bmp'
##FONT_FILE = DATA_DIR + 'cactus_plain.ttf'
