"""
The inspiration for this module came from Koen Witters's superb article
"deWiTTERS Game Loop", aka "Constant Game Speed independent of Variable FPS" at
http://www.koonsolo.com/news/dewitters-gameloop/.
 
Translated to Python and embellished by Gummbum. While the demo requires
Pygame, the module does not. The GameClock class is purely Python and should be
compatible with other Python-based multi-media and game development platforms.
 
Note that Python Library docs mention that time.clock() does not return
fractions of a second on all computer platforms. Therefore this module will not
work on such platforms.
"""
 
import time
 
class GameClock(object):
    """Run game engine at a constant game speed independent of variable FPS.
    Parameters:
        ticks_per_second -> Positive integer. Constant ticks per second for
            game physics.
        max_fps -> Positive integer. Max frames allowed per second. A value of
            zero allows unlimited frames.
        use_wait -> Boolean. When True, GameClock.tick() uses time.sleep to
            throttle frames per second. This uses less CPU at the postential
            cost of smoothness. When False, GameClock.tick() returns without
            injecting any waits, and can result in smoother frames.
        max_frame_skip -> Positive integer. Max game ticks allowed before
            forcing a frame display.
    Properties:
        ticks_per_second -> Read-write. See parameter ticks_per_second.
        max_fps -> Read-write. See parameter max_fps.
        use_wait -> Read-write. See parameter use_wait.
        max_frame_skip -> Read-write. See parameter max_frame_skip.
    Methods:
        tick() -> Game loop timer. Call once per game loop.
        interpolate() -> Return float as prediction factor.
        update_ready() -> Return boolean indicating if game should be updated.
        frame_ready() -> Return boolean indicating if display should be updated.
        get_fps() -> Return the frame rate from the previous second.
        get_ups() -> Return the update rate from the previous second.
    """
    
    def __init__(self, ticks_per_second=25, max_fps=0, use_wait=True, max_frame_skip=5):
        self.ticks_per_second = ticks_per_second
        self.max_fps = max_fps
        self.use_wait = use_wait
        self.max_frame_skip = 5
        #
        self._ticks = 0
        self._get_ticks = time.clock
        self._wait = time.sleep
        self._next_game_tick = self._get_ticks()
        self._next_frame = self._get_ticks()
        self._loops = 0
        self._update_ready = False
        self._frame_ready = False
        #
        self._time = self._get_ticks()
        self._elapsed = 0
        self._tick_count = 0
        self._tps = 0.0
        self._frame_count = 0
        self._fps = 0
        self._update_count = 0
        self._ups = 0
    
    @property
    def ticks_per_second(self):
        return self._ticks_per_second
    @ticks_per_second.setter
    def ticks_per_second(self, n):
        if n > 0:
            self._ticks_per_second = n
        else:
            self._ticks_per_second = 25
        self._skip_ticks = 1.0 / self._ticks_per_second
    
    @property
    def max_fps(self):
        return self._max_fps
    @max_fps.setter
    def max_fps(self, n):
        if n > 0:
            self._max_fps = n
            self._skip_frames = 1.0 / n
        else:
            self._max_fps = 0
            self._skip_frames = 0
    
    @property
    def use_wait(self):
        return self._use_wait
    @use_wait.setter
    def use_wait(self, enabled):
        self._use_wait = enabled
        self._tps = float(self.max_fps)
 
    @property
    def max_frame_skip(self):
        return self._max_frame_skip
    @max_frame_skip.setter
    def max_frame_skip(self, n):
        if n > 0:
            self._max_frame_skip = n
        else:
            self._max_frame_skip = 0
 
    def update_ready(self):
        """Call once per game loop. If True, update the game physics."""
        return self._update_ready
    
    def frame_ready(self):
        """Call once per game loop. If True, display a graphics frame."""
        return self._frame_ready
 
    def _flip(self):
        """Update runtime stats and counters every second."""
        time = self._get_ticks()
        self._ticks = time - self._time
        self._elapsed += self._ticks
        self._time = time
        # Once per second...
        if self._elapsed < 1:
            return
        else:
            self._elapsed -= 1
        # Save stats and clear counters.
        self._fps = self._frame_count
        self._ups = self._update_count
        self._tps = float(self._tick_count)
        self._frame_count = self._update_count = 0
 
    def tick(self):
        """Game loop timer. Call once per game loop to calculate runtime values.
        After calling, check the update_ready() and frame_ready() methods.
        Sleep cycles are injected if use_wait=True. Returns the number of
        milliseconds that have elapsed since the last call to tick()."""
        self._tps += 1
        self._flip()
        self._update_ready = self._frame_ready = False
        if self._get_ticks() > self._next_game_tick and \
            self._loops < self.max_frame_skip:
            self._update_count += 1
            self._next_game_tick += self._skip_ticks
            self._loops += 1
            self._update_ready = True
        if self._get_ticks() > self._next_frame or \
            self._loops >= self.max_frame_skip:
            self._frame_count += 1
            self._next_frame += self._skip_frames
            self._loops = 0
            self._frame_ready = True
        elif self._use_wait and self.max_fps > 0:
            ms = self._tps / self.max_fps
            if round(ms) >= 2:
                self._wait(ms/1000)
        return self._ticks
 
    def interpolate(self):
        """Return a float representing the current position in between the
        previous gametick and the next one. This allows the main game loop to
        make predictive calculations between gameticks."""
        return (
            self._get_ticks() + self._skip_ticks - self._next_game_tick
        ) / self._skip_ticks
    
    def get_fps(self):
        """Return frames per second during the previous second."""
        return self._fps
    
    def get_ups(self):
        """Return updates per second during the previous second."""
        return self._ups
    
#    def get_ticks(self):
#        return self._get_ticks()