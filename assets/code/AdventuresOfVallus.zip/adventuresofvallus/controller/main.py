'''
Created on 11 Oct 2010

@author: Rohin
'''
'''Game main module.

Contains the entry point used by the run_game.py script.

Feel free to put all your game code here, or in other modules in this "gamelib"
package.
'''

#-------------------------------------------------------------------------------------------------------------------------------------------------

#from pygame.locals import *
#import os
#import random
#from sys import exit

#from level import *
#from globals import *

#from objects import *
#from menu import *

#===============================================================================
# INCLUDES
#===============================================================================
import pygame
from pygame.locals import *

from gameclock import GameClock

from keyboard_controller import KeyboardController
from view.display import Display
from model import Model
from view.human_view import HumanView
#===============================================================================
# CONSTANTS
#===============================================================================
INTERPOLATION_ENABLED = False
TICKS_PER_SECOND = 25
MAX_FPS = 0                            #0 = Unlimited. We may need to set a max if trying to save CPU cycles
CLOCK_USE_WAIT = True
MAX_FRAME_SKIP = 5


#===============================================================================
# CLASSES
#===============================================================================
def main():
    engine = Engine()

    if engine.initalize():
        engine.run()
    
    engine.cleanup()
#===============================================================================
class Engine(object):
    def __init__(self):
        pass
    
    def initalize(self):
        self.game_is_running = True
        pygame.init()
        
        self.display = Display()
        self.clock = GameClock(TICKS_PER_SECOND, MAX_FPS, CLOCK_USE_WAIT, MAX_FRAME_SKIP)
        
        self.model = Model()
        self.view = HumanView(self.model, self.display, self.clock)
        self.keyboard_controller = KeyboardController(self.view)
        return True
        
    def cleanup(self): #Empty!
        pass
        
    def update_game(self):                       #TODO: Work out if we need to start calculating delta time.
        self.keyboard_controller.update()        
        self.model.update()
        self.view.update()

    def run(self):
        while self.game_is_running:
            self.clock.tick()
            if self.clock.update_ready():
                self.update_game()
            if self.clock.frame_ready():
                self.render_game()
            
            self.handle_events()

    def render_game(self):                          #TODO: Start calculating interpolation
        self.view.render()
        #self.print_fps()
        pygame.display.update()

    def handle_events(self):
        for e in pygame.event.get():
            if e.type == QUIT:
                self.game_is_running = False
            elif e.type == KEYDOWN:
                self.keyboard_controller.set_key(e.key, True)
            elif e.type == KEYUP:
                self.keyboard_controller.set_key(e.key, False)
#===============================================================================
