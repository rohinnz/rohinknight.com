'''
Created on 13 Dec 2010

@author: Rohin
'''
#===============================================================================
# INCLUDES
#===============================================================================
import pygame
from pygame.locals import *
from constants import *

#===============================================================================
# CONSTANTS
#===============================================================================
#ESCAPEJUMP, MOVE_LEFT, MOVE_RIGHT, THROW_ROCK = range(4)

#COMMAND_KEYS = [K_ESCAPE, K_SPACE, K_UP, K_LEFT, K_RIGHT]

COMMAND_KEYS = {
        K_UP: MOVE_UP,
        K_DOWN: MOVE_DOWN,
        K_LEFT: MOVE_LEFT,
        K_RIGHT: MOVE_RIGHT,
        K_ESCAPE: PAUSE,
        K_RETURN: SELECT,
        K_SPACE: ACTION_A
}

COMMAND_KEYS_LIST = COMMAND_KEYS.keys()

ALPHANUMERIC = 'abcdefghijklmnopqrstuvwxyz0123456789'

#===============================================================================
# CLASSES
#===============================================================================
class KeyboardController(object):
    def __init__(self, view):
        self.view = view

        #self.keysdown = []
        #self.keysup = []
        self.keys_released = []
        self.keys = {}
        for key in COMMAND_KEYS_LIST:
            self.keys[key]  = False
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def reset_keys_released(self):
        for i in self.keys_released:  self.keys_released.remove(i)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def set_key(self, key, is_down):
        if key in COMMAND_KEYS.keys():
            self.keys[key] = is_down
            
        if not is_down:
            self.keys_released.append(key)
                
    def _parse_keycode(self, keycode, is_down):
        
        # TODO: Precalculate K_z - K_a and K_9 - K_0
        
        if keycode in COMMAND_KEYS_LIST:
            self.view.handle_command_input(COMMAND_KEYS[keycode], is_down)
                    
        if keycode >= K_a and keycode <= K_z:
            index = keycode - K_a
            self.view.handle_alphanumeric_input( ALPHANUMERIC[index], is_down )
                
        elif keycode >= K_0 and keycode <= K_9:
            index_and_number = keycode - K_0
            self.view.handle_alphanumeric_input( ALPHANUMERIC[index_and_number + 26], is_down )
            self.view.handle_numeric_input( index_and_number, is_down )
            
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def update(self):      # TODO: Later set it up so movements are sent via the view
        for keycode in self.keys:
            if self.keys[keycode]:
                self._parse_keycode(keycode, True)
            
        for keycode in self.keys_released:
            self._parse_keycode(keycode, False)
            
        self.reset_keys_released()
        
        #view.handle_command_input()
        
#        
#        level = self.model.level
#        
#        # Menu
#        if K_ESCAPE in self.keys_released:
#            level.influence_pause()
#            
#        # Attack
#        if K_SPACE in self.keys_released:
#            level.influence_throw_rock()
#        
#        # Movement
#        if self.keys[K_UP]:
#            level.influence_jump()
#        if self.keys[K_LEFT]:
#            level.influence_move_left()
#        if self.keys[K_RIGHT]:
#            level.influence_move_right()
#
#
#
#
#        
#
#        # Cheats
#        if K_g in self.keys_released:
#            level.influence_toggle_cheat_god_mode()
#        if K_f in self.keys_released:
#            level.influence_toggle_cheat_fly()
#        if K_c in self.keys_released:
#            level.influence_toggle_cheat_no_clipping()
            


#===============================================================================