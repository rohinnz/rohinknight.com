'''
Created on 12 Oct 2010

@author: Rohin
'''
'''
Created on 12 Oct 2010

@author: Rohin
'''

#TODO: consider putting all entities in a seperate module called entities


#===============================================================================
# INCLUDES
#===============================================================================
from globals import *
from vector2 import Vector2
import random
#-------------------------------------------------------------------------------------------------------------------------------------------------
import os
import pygame
from pygame.locals import *
from utils import *     # We should not be using this because it is from the controller

from constants import *
#-------------------------------------------------------------------------------------------------------------------------------------------------

#from pygame.surfarray import *
#import pygame.surfarray as surfarray
#from numpy import *

#===============================================================================
# CONSTANTS
#===============================================================================
#LEFT, RIGHT, UP, DOWN = xrange(4)
#WIDTH, HEIGHT = xrange(2)

#===============================================================================
# CLASSES
#===============================================================================

# TODO: If we want to keep this in the model, then we must find a way to make the get_ticks() function abstract so Timer does not know where it is from
class Timer():
    #Timers_Paused = False
    Ticks_On_Pause = 0
    Paused_Ticks = 0
    
    def __init__(self, delay = 2000):
        self.end_ticks = pygame.time.get_ticks() + delay
        
    def reset(self, delay = 2000):
        self.end_ticks = pygame.time.get_ticks() + delay
        
    def is_time_up(self):
        return ( pygame.time.get_ticks() > self.end_ticks + Timer.Paused_Ticks)
    
    @classmethod
    def pause_all_timers(cls, pause_timers):
        if pause_timers:
            #Timers_Paused = True
            cls.Ticks_On_Pause = pygame.time.get_ticks()
        else:
            cls.Paused_Ticks = pygame.time.get_ticks() - cls.Ticks_On_Pause


#-------------------------------------------------------------------------------------------------------------------------------------------------
class State(object):
    def update(self):
        pass

    def render(self):
        pass
#-------------------------------------------------------------------------------------------------------------------------------------------------
class StateManager(object):
    def __init__(self): 
        self._states = []
    
    def pushState(self, state):
        self._states.append(state)

    def popState(self):
        return self._states.pop()

    def setState(self, state):
        self._states[-1] = state

    def update(self):
        self._states[-1].update()

    def render(self):
        self._states[-1].render()
        
    def empty(self):
        return not self._states


#=================================================================================================================
class Entity(object):
    def __init__(self):
        self.position = Vector2(0, 0)
        self.velocity = Vector2(0, 0)
        self.width = 0
        self.height = 0
        
    def update(self):
        pass
#=================================================================================================================
class Player(Entity):
    def __init__(self):
        # Physics        
        self.position = Vector2(0, 0)
        self.velocity = Vector2(0, 0)
        self.width = 46                       # TODO: Load with and height from file
        self.height = 40
        #self.max_x_speed = 0  
        self.jump_speed = 0
        self.grounded = False
        self.facing = RIGHT

        
        # Attributes - should be put in entity properties
        self.sick = False

#=================================================================================================================
class Projectile(Entity):
    def __init__(self, position, velocity):        
        # Physics
        self.position = position
        self.velocity = velocity
        self.width = 29
        self.height = 47      
        self.angle = 0
        self.rotate_speed = 10
        
#=================================================================================================================
class Baddie(Entity):
    def __init__(self, x, y):
        # Physics
        self.position = Vector2(x, y)
        self.velocity = Vector2(0, 0)
        self.grounded = False
        self.width = 54
        self.height = 24
        
        # Attributes
        self.baddie_throw_delay = Timer(2000)
#=================================================================================================================
class Factory(object):     # Factory design pattern
    def add_baddie(self):
        pass
        
    def add_player(self):
        pass
    
    def add_rock(self):
        pass
#=================================================================================================================
class Checkpoint(Entity):
    def __init__(self, x, y, w, h):
        self.position = Vector2(x, y)
        self.width = w
        self.height = h
#=================================================================================================================
        
#class BriefMessage():
#    def __init__(self, message):
#        self.timer = Timer()
#        self.message = message
#        self.font = pygame.font.Font(None, 28)
#        self.color = (160, 20, 20)
#        self.valid = True
#        
#    def update(self):
#        if self.timer.is_time_up():
#            self.valid = False
#
#    def render(self, camera):
#        text = self.font.render(self.message, 1, self.color)
#        textpos = (camera.width / 2 - 30, camera.height / 2 - 20) 
#        Globals.Screen.blit(text, textpos)
        
#class GameKeys():
#    def __init__(self):
#        self.keys = [K_UP, K_LEFT, K_RIGHT, K_DOWN]
#
#    def shufflekeys(self):
#        random.shuffle(self.keys)
#        
#    def swapkeys(self):
#        self.keys[MOVE_LEFT] = K_RIGHT
#        self.keys[MOVE_RIGHT] = K_LEFT
#        
#    def restorekeys(self):
#        self.keys[MOVE_LEFT] = K_LEFT
#        self.keys[MOVE_RIGHT] = K_RIGHT
    