'''
Created on 13 Dec 2010

@author: Rohin
'''

'''

TODO: Store listeners by their type, and then we only need to notify listeners which listen for a specific type.


Subsystems

* Sound Manager
* Display / Screen Manager
* Physics
* Menu Manager
* Animations Manager ?
* Resources Manager (Images, music, fonts, file manager)
* Timer 
* Network
* Input Manager (Keyboard controller, mouse controller)

* Utilities (Not really a subsystem)


Types
- Sound
    - Play Sound effect
    - Play music
    - Stop music
- Render
    - Print
    
- 

'''

from collections import deque
from utils import *

# Enum code copied from http://code.activestate.com/recipes/577024-yet-another-enum-for-python/
def enum(typename, field_names):
    "Create a new enumeration type"

    if isinstance(field_names, str):
        field_names = field_names.replace(',', ' ').split()
    d = dict((reversed(nv) for nv in enumerate(field_names)), __slots__ = ())
    return type(typename, (object,), d)()

EVENT_TYPES = enum('EVENT_TYPES',
    'SYSTEM'
    'VIEW'
    'INPUT,'
    'SOUND,'
    'MODEL')

EVENTS = enum('EVENTS',   
    'QUIT,'                              # SYSTEM
    'SCREEN_RESIZE,'
    
    'ENTITY_CREATED'                     # MODEL
    'ENTITY_DESTROYED'
    
    'MOVE_UP,'                            # Movement Input
    'MOVE_DOWN,'
    'MOVE_LEFT,'
    'MOVE_RIGHT,'
    'JUMP,'
    'THROW,'
    
    'PAUSE,'                              # Misc
    
    'SET_CHEAT_GODMODE,'                   # Cheats
    'SET_CHEAT_FLY,'
    'SET_CHEAT_NOCLIPPING,'
    
    'LEVEL_RESTARTED'
    
    'LOAD_MENU,'                          # Menu
    'MENU_LOADED')

class Event(object):
    def __init__(self, type, data):
        self.type = type
        
#TODO: Re-implement to prevent every listener getting notified for every event.

@singleton
class EventManager(object):
    def __init__(self):
        for type in eventtypes:
            self._listeners[type] = []
        
    def post_event(self, event):
        for type in self._listeners:
            for listener in self._listeners[type]:
                listener.notify(type, event)
                
    def attach_listener(self, types, event_listener):
        for type in types:
            if not self._listeners.haskey(type):
                self._listeners[type] = []
            
            self._listeners[type].append(event_listener)
        
    def detach_listener(self, event_listener):
        for type in self._listeners:
            if event_listener in self._listeners[type]:
                self._listeners[type].remove(event_listener)

        
class EventListener(object):
    def notify(self, type, event):
        pass