'''
Created on 15 Dec 2010

@author: Rohin
'''


# Commands
MOVE_UP, MOVE_DOWN, MOVE_LEFT, MOVE_RIGHT, PAUSE, SELECT, ACTION_A = range(7)


LEFT, RIGHT, UP, DOWN = xrange(4)
WIDTH, HEIGHT = xrange(2)



#AVAILABLE_KEYS = [K_ESCAPE, K_SPACE, K_UP, K_LEFT, K_RIGHT, K_g, K_f, K_c]