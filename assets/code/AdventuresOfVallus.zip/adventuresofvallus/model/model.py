'''
Created on 13 Dec 2010

@author: Rohin
'''
#===============================================================================
# INCLUDES
#===============================================================================
#from level import Level
import math

from tiledtmxloader import *
from objects import *
from vector2 import Vector2
from events import *

#===============================================================================
# CONSTANTS
#===============================================================================
PLAYING, PAUSED, GAME_OVER, PLAYER_WINS = range(4)


GRAVITY_SPEED = 1
MAX_FALL_SPEED = 10
PLAYER_SPEED = 10
JUMP_DIST = 16

TILE_WIDTH = 32    #TODO: Should be initialised when tmx map is loaded so we know we have the correct values. 
TILE_HEIGHT = 32


#RAPID_PLAYER_SPEED = 50
#RAPID_JUMP_DIST = 40
#RAPID_GRAVITY_SPEED = 4
#RAPID_MAX_FALL_SPEED = 20

#===============================================================================
# FUNCTIONS
#===============================================================================
def entity_collision(entity1, entity2):
    left1 = entity1.position.x
    left2 = entity2.position.x
    right1 = entity1.position.x + entity1.width
    right2 = entity2.position.x + entity1.width
    top1 = entity1.position.y
    top2 = entity2.position.y
    bottom1 = entity1.position.y + entity1.height
    bottom2 = entity2.position.y + entity2.height
    
    if left1 > right2 or right1 < left2 or top1 > bottom2 or bottom1 < top2:
        return False
    
    return True
#===============================================================================
# CLASSES
#===============================================================================
class Model(object):
    def __init__(self):
        self.level = Level()
        
    def update(self):
        self.level.update()
#===============================================================================        
class Level(State):
    def __init__(self):
        # --- TEMP VARS
        #self.tmp_stop = False
        
        
        # --- Load map
        self.map = TileMapParser().parse_decode(LEVEL_FILES['level1'])
        self.map.load(ImageLoaderPygame())
        
        self.indexed_tiles = {}
        for tileset in self.map.tile_sets[:]:
            for tile in tileset.tiles[:]:
                id = int(tileset.firstgid) + int(tile.id)
                self.indexed_tiles[id] = tile                
        
        self.map_width = self.map.layers[0].width * self.map.tilewidth
        self.map_height = self.map.layers[0].height * self.map.tileheight
        
        
        # --- Setup player and baddies
        self.player = Player()
        self.enemy_projectiles = []
        self.baddies = []
        
        self.state = PLAYING
        self.paused = False
        
        #TILE_WIDTH = self.map.tilewidth
        #TILE_HEIGHT = self.map.tileheight
        
        #self.gamekeys = GameKeys()

        
        # --- Checkpoints
        self.checkpoints = []
        self.last_checkpoint = None
        
        self.load_game_objs()
        
        # --- Setup camera
        #self.camera = Camera(self.map_width, self.map_height)                
        #self.camera.update(self.player)
  
        # --- Setup first message to be displayed
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
    
        # --- Cheats
        self.cheats_godmode = False
        self.cheats_fly = False
        self.cheats_noclipping = False
#        self.cheats_rapid_speed = False

        # --- Pause menu
        #self.menu = Menu('GAME PAUSED', ('Resume Game', 'Restart Level', 'Help', 'Quit'))
        
        # --- parallax background
        #self.parallax_background = Parallax()
        
        # --- Register to be notified about events
        #EventManager().attach_listener(self)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def return_to_last_checkpoint(self):
        self.enemy_projectiles = []        
        self.player.velocity = Vector2(0, 0)
        self.player.position.x = self.last_checkpoint.position.x
        self.player.position.y = self.last_checkpoint.position.y + self.last_checkpoint.height - self.player.height
        
        self.paused = False      #TODO: Add a new state called PAUSED
        self.state = PLAYING
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def restart_level(self):
        
        self.player.velocity = Vector2(0, 0)
        self.enemy_projectiles = []
        self.baddies = []
        self.load_game_objs()
        
        self.paused = False
        self.state = PLAYING                
        self.game_over_msg_delay = None
        self.run_msg_delay = Timer(2000)
        
        #EventManager().post_event(EVENT_TYPE.PLAYER_MOVED, self.player.rect)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def load_game_objs(self):
        #=======================================================================
        # Load objects
        #=======================================================================
        for obj_group in self.map.object_groups:
                for obj in obj_group.objects[:]:
                    name = str.lower(str(obj.name))
                    
                    if name == 'playerstart':
                        self.player.position.x = obj.x
                        self.player.position.y = obj.y + TILE_HEIGHT - self.player.height
                    elif name == 'baddie':
                        self.baddies.append(Baddie(obj.x, obj.y))
                    elif name == 'checkpoint':
                        self.checkpoints.append(Checkpoint(obj.x, obj.y, obj.width, obj.height))
                    else:
                        raise 'Unknown object name: %s'  % name
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def notify(self, event):
        if event.type == EVENTS.PAUSE_LEVEL:
            self.paused = event.data
        elif event.type == EVENTS.RESTART_LEVEL:
            self.restart_level()
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def update(self):        
        if self.state == PLAYING:
            self.update_player()
            self.update_projectiles()
            self.update_baddies()
            
        elif self.state == GAME_OVER:
            if self.game_over_msg_delay == None:
                self.game_over_msg_delay = Timer(2000)
            elif self.game_over_msg_delay.is_time_up():
                if self.last_checkpoint != None:
                    self.return_to_last_checkpoint()
                else:
                    self.restart_level()
                
        elif self.state == PLAYER_WINS:
            if self.game_over_msg_delay == None:
                self.game_over_msg_delay = Timer(4000)
            elif self.game_over_msg_delay.is_time_up():
                self.restart_level()        
#--------------------------------------------------------------------------------------------------------------------------------------------------------------        
    def update_player(self):
        if not self.cheats_godmode:
            # Check if we have landed on any spikes
            tile_x, tile_y, img_idx = self.get_death_tile(self.player)
            if img_idx:
                self.state = GAME_OVER
                
            # Check if we have collided with any baddies
            for baddie in self.baddies:
                if entity_collision(self.player, baddie):
                    self.state = GAME_OVER
        
        if self.player.position.x > self.map_width - 120:
            self.state = PLAYER_WINS
        
        self.apply_gravity(self.player)
        
        if self.cheats_noclipping:
            self.player.position.x += self.player.velocity.x
            self.player.position.y += self.player.velocity.y
        else:
            collision = self.do_x_tile_clipping(self.player)
            
            if collision:
                self.player.velocity.x = 0
                
            self.do_y_tile_clipping(self.player)
            
        self.do_screen_boundary_clipping(self.player)
        
        # Start to slow down player
        
        
        if self.player.velocity.x > 1:
            self.player.velocity.x -= 1
        elif self.player.velocity.x < -1:
            self.player.velocity.x += 1
        else:
            self.player.velocity.x = 0
        
        # Has player reached a checkpoint?
        for checkpoint in self.checkpoints:
            if entity_collision(self.player, checkpoint):
                self.last_checkpoint = checkpoint

#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def update_baddies(self):
        MAX_DISTANCE = 1000
        MIN_DISTANCE = 100
        
        for baddie in self.baddies:
            if True:
            #if baddie.rect.colliderect(self.camera.rect):

                self.apply_gravity(baddie)
                collision = self.do_x_tile_clipping(baddie)
                
#                if collision:
#                    if baddie.dx > 0:
#                        baddie.dx = -4
#                    else:
#                        baddie.dx = 4
                    
                self.do_y_tile_clipping(baddie)
                self.do_screen_boundary_clipping(baddie)
                
                if baddie.baddie_throw_delay.is_time_up() and \
                   ((baddie.position.x + MIN_DISTANCE < self.player.position.x and baddie.position.x + MAX_DISTANCE > self.player.position.x) or \
                   (self.player.position.x + MIN_DISTANCE < baddie.position.x and self.player.position.x + MAX_DISTANCE > baddie.position.x)) and \
                   self.player.position.y > baddie.position.y:
                    
                    baddie.baddie_throw_delay.reset(1500)
                    self.baddie_throw_rock(baddie)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------     
    def player_throw_rock(self):
        pass
#        DX = 14.0
#        DY = 18.0
#        
#        x = self.player.rect.centerx
#        y = self.player.position.y
#        
#        if self.player.direction == 'right':
#            dx = DX
#        else:
#            dx = -DX
#        
#        self.enemy_projectiles.append(Projectile(x, y, dx, -DY))
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def baddie_throw_rock(self, baddie):
        '''
            Formula for calculating inital velocity required for projectile to reach player. - Special thanks to Ashvin for making v the subject
        
            v = dg / sqrt( 2((cosO)^2)gy + 2sinOcosOdg )
        
            Let d = distance
            Let g = gravity
            Let y = velocity
            Let theta = 45 degress in radians
        '''

        d = math.fabs(self.player.position.x - baddie.position.x)
        y = self.player.position.y - baddie.position.y
        theta = math.radians(45)
        
        velocity = d * GRAVITY_SPEED / math.sqrt(2 * (math.cos(theta)**2) *    \
                       GRAVITY_SPEED * y + 2 * math.sin(theta) *               \
                       math.cos(theta) * d * GRAVITY_SPEED)
        
        # --- Get x and y velocities using sine and cosine.
        dx = velocity * math.cos(theta)
        dy = velocity * math.sin(theta)
        
        # --- Make dx negative if projectile is travelling left
        if self.player.position.x - baddie.position.x < 0:
            dx = -dx
    
    
        position = baddie.position.copy()
        position.y -= 50
        projectile = Projectile(position, Vector2(dx, -dy))                # TODO: Use a factory to create projectiles
        #projectile = Projectile('xxx bottle', Vector2(baddie.position.xy), Vector2(dx, -dy))                # TODO: Use a factory to create projectiles
        self.enemy_projectiles.append(projectile)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def update_projectiles(self):
        for projectile in self.enemy_projectiles:
            self.apply_gravity(projectile)
            projectile.update()

            if projectile.position.y > self.map_height:
                self.enemy_projectiles.remove(projectile)
            elif self.do_x_tile_clipping(projectile): 
                #projectile.dx = 0
                self.enemy_projectiles.remove(projectile)
            elif self.do_y_tile_clipping(projectile):
                self.enemy_projectiles.remove(projectile)
            else:                
                if not self.cheats_godmode and entity_collision(projectile, self.player):
                    #self.player.is_sick = True                    
                    self.state = GAME_OVER

#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def apply_gravity(self, entity):
        entity.velocity.y += GRAVITY_SPEED        
        if entity.velocity.y > MAX_FALL_SPEED:
            entity.velocity.y = MAX_FALL_SPEED
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def do_screen_boundary_clipping(self, entity):
        collision = False
        
        if entity.position.x < 0:                                                                   
            entity.position.x = 0
            entity.velocity.x = 0
            collision = True
            
        elif entity.position.x > self.map_width - entity.width:
            entity.position.x = self.map_width - entity.width
            entity.velocity.x = 0
            collision = True
            
        if entity.position.y < 0:                                                              
            entity.position.y = 0
            entity.velocity.y = 0
            collision = True
            
        elif entity.position.y > self.map_height - entity.height: 
            entity.position.y = self.map_height - entity.height
            entity.grounded = True
            entity.velocity.y = 0
            collision = True
            
        return collision
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    ## Does x clipping for entity and returns true if there was a collision
    def do_x_tile_clipping(self, entity):
        new_x = entity.position.x + entity.velocity.x
        tile_x, tile_y, img_idx = self.get_collision_solid_tile(new_x, entity.position.y, entity)
                
        if img_idx == False:
            entity.position.x = new_x
            return False
        else:
                # line up with the tile boundary
            if entity.velocity.x > 0:
                entity.position.x = (tile_x * TILE_WIDTH) - entity.width
            else:  # entity.velocity.x < 0
                entity.position.x = (tile_x * TILE_WIDTH) + TILE_WIDTH
                
            #assert(entity.velocity.x != 0)
            
            return True
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    ## Does y clipping for entity and returns true if there was a collision
    def do_y_tile_clipping(self, entity):
        #First check if we are on a platform
        new_y = entity.position.y + entity.velocity.y
        on_platform = False
        
        if entity.velocity.y > 0:
            tile_x, tile_y, img_idx = self.get_collision_platform_tile(entity.position.x, new_y, entity)
            
            if img_idx != False:
                on_platform = True
                entity.position.y = (tile_y * TILE_HEIGHT) - entity.height
                entity.grounded = True
                entity.velocity.y = 0

        #IF we aren't on a platform, then check if we are on a solid
        if on_platform:
            return True
        else:
            tile_x, tile_y, img_idx = self.get_collision_solid_tile(entity.position.x, new_y, entity)
        
            if img_idx == False:
                entity.position.y = new_y
                entity.grounded = False
                return False
            else:                                                            # line up with the tile boundary
                if entity.velocity.y > 0:
                    entity.grounded = True
                    entity.position.y = (tile_y * TILE_HEIGHT) - entity.height 
                else:    # entity.velocity.y > 0
                    entity.position.y = (tile_y * TILE_HEIGHT) + TILE_HEIGHT    
                    
                #assert(entity.velocity.y != 0) - Can be true if just leaving no clipping
                     
                entity.velocity.y = 0
                return True
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def get_death_tile(self, entity):
        from_x = entity.position.x
        from_y = entity.position.y
        to_x = from_x
        to_y = from_y
        
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'death')
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def get_collision_solid_tile(self, new_x, new_y, entity):
        from_x = min(entity.position.x, new_x)
        from_y = min(entity.position.y, new_y)
        to_x = max(entity.position.x, new_x)
        to_y = max(entity.position.y, new_y)
                
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'solid')
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def get_collision_platform_tile(self, new_x, new_y, entity):  # You may pass through a platform tile and you can stand on top of it
        from_x = min(entity.position.x, new_x)
        from_y = entity.position.y + entity.height + TILE_HEIGHT - 1
        to_x = max(entity.position.x, new_x)
        to_y = new_y
        
        return self.get_collision_tile(from_x, from_y, to_x, to_y, entity, 'platform')
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def get_collision_tile(self, from_x, from_y, to_x, to_y, entity, tile_type):   # Will the entity collide with a solid tile?
        FROM_TILE_X = int(from_x) / TILE_WIDTH
        FROM_TILE_Y = int(from_y) / TILE_HEIGHT
        TO_TILE_X =  (int(to_x) + entity.width - 1) / TILE_WIDTH + 1
        TO_TILE_Y = (int(to_y) + entity.height - 1) / TILE_HEIGHT + 1
        
        if FROM_TILE_X < 0:                     FROM_TILE_X = 0
        elif TO_TILE_X > self.map.width:    TO_TILE_X = self.map.width
        if FROM_TILE_Y < 0:                     FROM_TILE_Y = 0
        elif TO_TILE_Y > self.map.height:   TO_TILE_Y = self.map.height
            
        # -- All layers are treated as visible
        for layer in self.map.layers[:]:
            for xpos in xrange(FROM_TILE_X, TO_TILE_X):
                for ypos in xrange(FROM_TILE_Y, TO_TILE_Y):

                    img_idx = layer.content2D[xpos][ypos]      
                    
                    #if img_idx:
                    if img_idx and img_idx in self.indexed_tiles:       # -- Check for collision
                        tile = self.indexed_tiles[img_idx]
                        
                        if tile_type in tile.properties:
                            return (xpos, ypos, img_idx)

        return (0, 0, False) 
#--------------------------------------------------------------------------------------------------------------------------------------------------------------
    def influence_pause(self):
        if self.state == PLAYING:
            self.state = PAUSED
            Timer.pause_all_timers(True)
        elif self.state == PAUSED:
            self.state = PLAYING
            Timer.pause_all_timers(False)

    def influence_throw_rock(self):
        if not self.paused:
            self.player_throw_rock()

    def influence_jump(self):
        if not self.paused and (self.player.grounded or self.cheats_fly):
            self.player.velocity.y = -JUMP_DIST
            self.player.grounded = False

    def influence_move_left(self):               
        if not self.paused: 
            self.player.velocity.x = -PLAYER_SPEED
            self.player.facing = LEFT

    def influence_move_right(self):
        if not self.paused:
            self.player.velocity.x = PLAYER_SPEED
            self.player.facing = RIGHT
        
    def influence_toggle_cheat_god_mode(self):
        self.cheats_godmode = not self.cheats_godmode
    
    def influence_toggle_cheat_fly(self):
        self.cheats_fly = not self.cheats_fly

    def influence_toggle_cheat_no_clipping(self):
        self.cheats_noclipping = not self.cheats_noclipping
