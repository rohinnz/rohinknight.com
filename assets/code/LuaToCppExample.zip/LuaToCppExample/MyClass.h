#ifndef MyClass_H
#define MyClass_H

class MyClass { //tolua_export

   private:
   int health;
   public:
   //tolua_begin
   void SetHealth(int amt) { health = amt; }
}; //tolua_end

#endif
