/*
** Lua binding: Player
** Generated automatically by tolua++-1.0.92 on 07/27/10 12:10:28.
*/

/* Exported function */
TOLUA_API int  tolua_Player_open (lua_State* tolua_S);

