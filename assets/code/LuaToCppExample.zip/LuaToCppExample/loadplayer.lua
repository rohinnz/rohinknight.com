
-- Create new Player object and set health
player = Player:new()
player:setHealth(4)

-- Display players health
io.write("LUA: Player's health is "..player:getHealth());
