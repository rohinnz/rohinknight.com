//#include "MyClass.h"
//
//void Actor::SetHealth(int amt)t
//{
//    health = amt
//}
