/*
** Lua binding: pkgname
** Generated automatically by tolua++-1.0.92 on 07/26/10 18:03:07.
*/

/* Exported function */
TOLUA_API int  tolua_pkgname_open (lua_State* tolua_S);

