Puzzle Game - Prototype 3
=========================

Start game by running Prototype3/Paralaxer.exe

-- Movement --
Arrow keys or click in the direction you want the player to move

-- Item Selection --
Numbers 1-5, or click on the item to select it in my right pane.

-- Item Placement --
Click next to the player where you want to place the item.

-- Restart --
Click the skull and crossbones button.

-- Saving --
The game auto-saves the current level you are up to and will start from that level the next time you open the game.