#include "MessageApp.h"

int main(int, const char* [])
{
	return MessageApp().run();
}
